from pmaf.shared import Consts
from os import path
import pandas as pd
import pickle
import tables
from collections import OrderedDict
import warnings

warnings.simplefilter('ignore', tables.NaturalNameWarning,append=True)
warnings.simplefilter('ignore', tables.PerformanceWarning,append=True)

class DatabaseStorageManager:
    _default_interxmap_key = 'inter-index-map'

    def __init__(self,hdf5_filepath,storage_name,force_new=False, reset_internals=False):
        self._storer = None
        self._storer_state = False
        self._storer_mode = None # Value can be either `pandas` or `tables`
        self._hdf5_filepath = None
        self._storage_name = None
        self._parser_elements = {}
        self._init_state = False
        self._parser_elements_state = OrderedDict()
        self._element_keys_cache = []
        if isinstance(storage_name,str) and isinstance(hdf5_filepath,str):
            if len(storage_name)>0 and len(hdf5_filepath)>0:
                if not path.exists(hdf5_filepath) or force_new:
                    self._create_storage(hdf5_filepath,storage_name)
                    self._hdf5_filepath = hdf5_filepath
                    self._storage_name = storage_name
                    self._init_state = True
                else:
                    if self.validate_storage(hdf5_filepath,storage_name):
                        self._hdf5_filepath = hdf5_filepath
                        self._storage_name = storage_name
                        self._init_state = True
                        if reset_internals:
                            if not self.reset_internals():
                                raise RuntimeError('Failed to initiate internals.')
                    else:
                        raise ValueError('Storage file or storage name is invalid.')
            else:
                raise ValueError('Storage file or storage name is invalid.')
        else:
            raise ValueError('Storage file or storage name is invalid.')

    def reset_internals(self):
        ret = False
        if self.check_init():
            if self._init_element_key_cache():
                ret = True
        return ret

    def shutdown_manager(self):
        ret = False
        if self.check_init():
            self._element_keys_cache = []
            ret = self.close_storage()
        return ret

    @staticmethod
    def validate_parser_elements(parser_elements_dict):
        ret = False
        if len(parser_elements_dict)>0:
            if all([struct_elem in Consts.DATABASE_HDF5_STRUCT.keys() or struct_elem.startswith('pass-dummy-') for struct_elem in parser_elements_dict.keys()]):
                tmp_internal_verify = True
                default_internal_keys = ['handle','params','pass','receive']
                for solo_parser_element in parser_elements_dict.values():
                    if isinstance(solo_parser_element,dict):
                        if all([elem_key in default_internal_keys for elem_key in solo_parser_element.keys()]):
                            for elem_key, elem_val in solo_parser_element.items():
                                if elem_key == 'handle':
                                    tmp_internal_verify = tmp_internal_verify and callable(elem_val)
                                elif elem_key == 'params':
                                    tmp_internal_verify = tmp_internal_verify and isinstance(elem_val,tuple)
                                elif elem_key == 'pass':
                                    tmp_internal_verify = tmp_internal_verify and (isinstance(elem_val,int) or (isinstance(elem_val,bool)))
                                elif elem_key == 'receive':
                                    tmp_internal_verify = tmp_internal_verify and (elem_val is None or isinstance(elem_val,str))
                                    if isinstance(elem_val,str):
                                        tmp_internal_verify = tmp_internal_verify and (elem_val in parser_elements_dict.keys())
                                else:
                                    tmp_internal_verify = False
                                    break
                    else:
                        tmp_internal_verify = False
                        break
                ret = tmp_internal_verify
        return ret

    def _init_parser_elements_state(self):
        tmp_parser_elements_state = OrderedDict()
        first_pass_elements = []
        receive_elements = []

        for elem_key, elem_value in self._parser_elements.items():
            if elem_value['pass']==0 and elem_value['receive'] is None:
                tmp_parser_elements_state.update({elem_key: elem_value})
            if elem_value['pass']>0 and elem_value['receive'] is None:
                first_pass_elements.append(elem_key)
            if elem_value['receive'] is not None:
                receive_elements.append(elem_key)

        for pass_elem_key in first_pass_elements:
            tmp_parser_elements_state.update({pass_elem_key: self._parser_elements[pass_elem_key]})
            pass_receive_state = True
            last_pass_key =  pass_elem_key
            last_receive_key = None
            while pass_receive_state:
                for elem_key, elem_value in self._parser_elements.items():
                    if last_pass_key == elem_value['receive']:
                        last_receive_key = elem_key
                if last_receive_key is not None:
                    tmp_parser_elements_state.update({last_receive_key: self._parser_elements[last_receive_key]})
                if self._parser_elements[last_receive_key]['pass']>0:
                    last_pass_key = last_receive_key
                else:
                    pass_receive_state = False
        for elem_key in tmp_parser_elements_state.keys():
            self._parser_elements_state.update({elem_key:False})
        return

    def assign_parser_elements(self,parser_elements):
        ret = False
        if self.check_init():
            if self.validate_parser_elements(parser_elements):
                for parser_element in parser_elements.values():
                    parser_element['pass'] = int(parser_element['pass'])
                self._parser_elements = parser_elements
                self._init_parser_elements_state()
                ret = True
            else:
                raise ValueError('Parser elements are invalid.')
        return ret

    def check_init(self):
        return self._init_state

    def check_state(self):
        ret = False
        if self.check_init():
            if len(self._element_keys_cache)>0:
                ret = True
        return ret

    def storer_state(self):
        ret = False
        if self._storer_state:
            ret = self._storer_mode
        return ret

    def close_storage(self):
        ret = False
        if self.check_init():
            if self._storer_state:
                if self._storer_mode == 'pandas':
                    self._storer.close()
                    self._storer_state = False
                    ret = True
                elif self._storer_mode == 'tables':
                    self._storer.close()
                    self._storer_state = False
                    ret = True
        return ret

    def open_storage_as_tables(self,mode='a'):
        ret = False
        if self.check_init():
            self.close_storage()
            self._storer = tables.open_file(self._hdf5_filepath, mode=mode)
            self._storer_mode = 'tables'
            self._storer_state = True
            ret = True
        return ret

    def open_storage_as_pandas(self,mode='a'):
        ret = False
        if self.check_init():
            self.close_storage()
            self._storer = pd.HDFStore(self._hdf5_filepath,mode=mode)
            self._storer_mode = 'pandas'
            self._storer_state = True
            ret = True
        return ret

    def commit_to_storage(self):
        ret = False
        if self.check_init() and len(self._parser_elements_state)>0:
            element_pass_value = None
            for elem_key in self._parser_elements_state.keys():
                active_element = self._parser_elements[elem_key]
                parser_handle = active_element['handle']
                parser_params = active_element['params'] if active_element['receive'] is None else active_element['params']+(element_pass_value,)
                put_state,tmp_element_pass_value = self._put_to_storage(elem_key,parser_handle,parser_params)
                if put_state:
                    if active_element['pass'] != 2:
                        element_pass_value = tmp_element_pass_value
                else:
                    raise RuntimeError('Error during parsing data and committing to storage file.')
                self._parser_elements_state[elem_key] = True
            ret = all(self._parser_elements_state.values())
        return ret

    def _put_to_storage(self,element_key,parser_handle,parser_params):
        ret_state = False
        ret_value = None
        if element_key == 'sequence-master':
            if self.open_storage_as_pandas():
                parsed_sequence_generator = parser_handle(*parser_params)
                pre_table_state, first_chunk = next(parsed_sequence_generator)
                max_rows = pre_table_state.pop('max_rows')
                self._storer.put(Consts.DATABASE_HDF5_STRUCT[element_key], first_chunk, format='table', data_columns=True,min_itemsize=pre_table_state,expectedrows=max_rows,index=False)
                for chunk in parsed_sequence_generator:
                    self._storer.append(Consts.DATABASE_HDF5_STRUCT[element_key], chunk, format='table', data_columns=True,min_itemsize=pre_table_state,expectedrows=max_rows,index=False)
                self._storer.get_node(Consts.DATABASE_HDF5_STRUCT[element_key])._v_title = element_key
                self._storer.create_table_index(Consts.DATABASE_HDF5_STRUCT[element_key], columns=['index'], optlevel=9, kind='full')
                ret_state = True
                ret_value = None
        elif element_key == 'sequence-aligned':
            if self.open_storage_as_pandas():
                parsed_sequence_generator_aligned = parser_handle(*parser_params)
                pre_table_state, first_chunk = next(parsed_sequence_generator_aligned)
                max_rows = pre_table_state.pop('max_rows')
                self._storer.put(Consts.DATABASE_HDF5_STRUCT[element_key], first_chunk, format='table',data_columns=True,min_itemsize=pre_table_state,expectedrows=max_rows,index=False)
                for chunk in parsed_sequence_generator_aligned:
                    self._storer.append(Consts.DATABASE_HDF5_STRUCT[element_key], chunk, format='table',data_columns=True,min_itemsize=pre_table_state,expectedrows=max_rows,index=False)
                self._storer.get_node(Consts.DATABASE_HDF5_STRUCT[element_key])._v_title = element_key
                self._storer.create_table_index(Consts.DATABASE_HDF5_STRUCT[element_key], columns=['index'], optlevel=9,kind='full')
                ret_state = True
                ret_value = None
        elif element_key == 'sequence-accession':
            if self.open_storage_as_pandas():
                parsed_sequences_accessions = parser_handle(*parser_params)
                self._storer.put(Consts.DATABASE_HDF5_STRUCT[element_key], parsed_sequences_accessions, format='table',data_columns=True)
                self._storer.get_node(Consts.DATABASE_HDF5_STRUCT[element_key])._v_title = element_key
                ret_state = True
                ret_value = parsed_sequences_accessions
        elif element_key == 'taxonomy-map':
            if self.open_storage_as_pandas():
                tax_master_map = parser_handle(*parser_params)
                self._storer.put(Consts.DATABASE_HDF5_STRUCT[element_key], tax_master_map, format='table',data_columns=True)
                self._storer.get_node(Consts.DATABASE_HDF5_STRUCT[element_key])._v_title = element_key
                ret_state = True
                ret_value = tax_master_map
        elif element_key == 'taxonomy-sheet':
            if self.open_storage_as_pandas():
                tax_parsed_map = parser_handle(*parser_params)
                self._storer.put(Consts.DATABASE_HDF5_STRUCT[element_key], tax_parsed_map, format='table', data_columns=True)
                self._storer.get_node(Consts.DATABASE_HDF5_STRUCT[element_key])._v_title = element_key
                ret_state = True
                ret_value = tax_parsed_map
        elif element_key == 'taxonomy-summary':
            if self.open_storage_as_pandas():
                tax_summary = parser_handle(*parser_params)
                self._storer.put(Consts.DATABASE_HDF5_STRUCT[element_key], tax_summary,format='table', data_columns=True)
                self._storer.get_node(Consts.DATABASE_HDF5_STRUCT[element_key])._v_title = element_key
                ret_state = True
                ret_value = tax_summary
        elif element_key == 'tree-map':
            if self.open_storage_as_pandas():
                tree_map_dataframe = parser_handle(*parser_params)
                self._storer.put(Consts.DATABASE_HDF5_STRUCT[element_key], tree_map_dataframe, format='table',data_columns=True)
                self._storer.get_node(Consts.DATABASE_HDF5_STRUCT[element_key])._v_title = element_key
                ret_state = True
                ret_value = tree_map_dataframe
        elif element_key == 'tree-parsed':
            if self.open_storage_as_tables():
                tree_master_parsed = parser_handle(*parser_params)
                tree_master_parsed_utf8 = tree_master_parsed.encode('utf-8')
                self._storer.get_node(Consts.DATABASE_HDF5_STRUCT[element_key]).append(tree_master_parsed_utf8)
                ret_state = True
                ret_value = tree_master_parsed
        elif element_key == 'tree-object':
            if self.open_storage_as_tables():
                tree_object = parser_handle(*parser_params)
                tree_object_bytes = pickle.dumps(tree_object)
                self._storer.get_node(Consts.DATABASE_HDF5_STRUCT[element_key]).append(tree_object_bytes)
                ret_state = True
                ret_value = tree_object
        elif element_key.startswith('pass-dummy-'):
            dummy_result = parser_handle(*parser_params)
            ret_state = True
            ret_value = dummy_result
        return ret_state,ret_value

    def put_interxmap_to_storage(self,inter_index_map_df):
        ret = False
        if self.check_init():
            if self.open_storage_as_pandas():
                self._storer.put(Consts.DATABASE_HDF5_STRUCT[self._default_interxmap_key], inter_index_map_df, format='fixed', data_columns=True)
                self._storer.get_node(Consts.DATABASE_HDF5_STRUCT[self._default_interxmap_key])._v_title = self._default_interxmap_key
                ret = True
        return ret

    def retrieve_interxmap_from_storage(self):
        ret = None
        if self.check_state():
            if self.open_storage_as_pandas():
                if self.validate_element_key(self._default_interxmap_key):
                    ret = self._storer.select(Consts.DATABASE_HDF5_STRUCT[self._default_interxmap_key])
        return ret

    def _init_element_key_cache(self):
        ret = False
        if self.check_init():
            self.open_storage_as_tables('r')
            title_list = []
            for group in self._storer.walk_groups():
                if group._v_title in Consts.DATABASE_HDF5_STRUCT.keys():
                    if group._v_nchildren > 0:
                        if group._v_children.values()[0]._v_title == 'bytes':
                            if group._v_children.values()[0].nrows > 0:
                                title_list.append(group._v_title)
                        else:
                            title_list.append(group._v_title)
            if len(title_list)>0:
                self._element_keys_cache = title_list
                ret = True
        return ret


    @staticmethod
    def validate_storage(hdf5_filepath,storage_name):
        ret = False
        storage = tables.open_file(hdf5_filepath, mode='r')
        if storage.title == storage_name:
            title_list = []
            path_list = []
            for node in storage.walk_nodes():
                title_list.append(node._v_title)
                path_list.append(node._v_pathname)
            title_verify = all([title in title_list[1:] for title in Consts.DATABASE_HDF5_STRUCT.keys()])
            path_verify = all([path in path_list[1:] for path in Consts.DATABASE_HDF5_STRUCT.values()])
            ret = title_verify and path_verify
        storage.close()
        return ret

    @staticmethod
    def _create_storage(hdf5_filepath,storage_name):
        storage = tables.open_file(hdf5_filepath,mode='w',title=storage_name)

        storage.create_group('/','tree',title='root-tree')
        storage.create_group('/tree', 'map', title='tree-map')
        storage.create_group('/tree', 'parsed', title='tree-parsed')
        storage.create_group('/tree', 'pickled', title='tree-object')
        storage.create_vlarray('/tree/parsed', 'value', title='bytes', atom=tables.VLUnicodeAtom())
        storage.create_vlarray('/tree/pickled', 'value', title='bytes', atom=tables.ObjectAtom())

        storage.create_group('/', 'tax', title='root-taxonomy')
        storage.create_group('/tax', 'master', title='taxonomy-map')
        storage.create_group('/tax', 'parsed', title='taxonomy-sheet')

        storage.create_group('/','seq',title='root-sequences')
        storage.create_group('/seq', 'master', title='sequence-master')
        storage.create_group('/seq', 'aligned', title='sequence-aligned')
        storage.create_group('/seq', 'accession', title='sequence-accession')

        storage.create_group('/', 'meta', title='root-metadata')
        storage.create_group('/meta', 'taxonomy', title='taxonomy-summary')
        storage.create_group('/meta', 'interxmap', title='inter-index-map')

        storage.close()
        return

    @staticmethod
    def _detect_storer_mode_by_element(element_key):
        ret = False
        if element_key == 'sequence-master':
            ret = 'pandas'
        elif element_key == 'sequence-aligned':
            ret = 'pandas'
        elif element_key == 'sequence-accession':
            ret = 'pandas'
        elif element_key == 'taxonomy-map':
            ret = 'pandas'
        elif element_key == 'taxonomy-sheet':
            ret = 'pandas'
        elif element_key == 'taxonomy-summary':
            ret = 'pandas'
        elif element_key == 'tree-map':
            ret = 'pandas'
        elif element_key == 'tree-parsed':
            ret = 'tables'
        elif element_key == 'tree-object':
            ret = 'tables'

        return ret

    def validate_element_key(self,element_key):
        ret = False
        if element_key in self._element_keys_cache:
            ret = True
        return ret

    def get_handle_by_element(self,element_key):
        ret = False
        if self.check_init():
            if self.validate_element_key(element_key):
                storer_mode = self._detect_storer_mode_by_element(element_key)
                if storer_mode != self.storer_state():
                    if storer_mode=='pandas':
                        if self.open_storage_as_pandas('r'):
                            ret = self._storer
                    elif storer_mode=='tables':
                        if self.open_storage_as_tables('r'):
                            ret = self._storer
                else:
                    ret = self._storer
        return ret

    def get_index_by_element(self,target_element_key):
        ret = None
        if self.check_state():
            if self.validate_element_key(target_element_key):
                storer_mode = self._detect_storer_mode_by_element(target_element_key)
                element_valid = False
                if storer_mode == 'pandas':
                    if storer_mode != self.storer_state():
                        if self.open_storage_as_pandas('r'):
                            element_valid = True
                    else:
                        element_valid = True
                if element_valid:
                    ret = self._storer.select_column(Consts.DATABASE_HDF5_STRUCT[target_element_key], 'index')
        return ret

    def compress_storage(self,complevel=9,complib='blosc',overwrite=False):
        ret = False
        if self.check_init() and not self.check_state():
            if path.exists(self._hdf5_filepath) and isinstance(complevel,int):
                if complevel<10 and complevel>0:
                    import subprocess
                    import os
                    self.open_storage_as_tables()
                    original_title = self._storer.title
                    self.close_storage()
                    hdf5_abs_path = path.abspath(self._hdf5_filepath)
                    hdf5_dir_path = path.dirname(hdf5_abs_path)
                    hdf5_basename = path.basename(hdf5_abs_path)
                    hdf5_filename = path.splitext(hdf5_basename)[0]
                    hdf5_extension = path.splitext(hdf5_basename)[1]
                    compressed_hdf5_basename = "{}.compressed{}".format(hdf5_filename,hdf5_extension)
                    compressed_hdf5_abs_path = "{}/{}".format(hdf5_dir_path,compressed_hdf5_basename)
                    ptrepack_cmd = "ptrepack --dest-title={} --chunkshape=auto --propindexes --complevel={} --complib={}".format(original_title,str(complevel),complib).split()
                    ptrepack_cmd.extend([hdf5_abs_path,compressed_hdf5_abs_path])
                    process = subprocess.Popen(ptrepack_cmd, stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                    output, error = process.communicate()
                    output = output.decode() if isinstance(output,bytes) else output
                    error = error.decode() if isinstance(error, bytes) else error
                    process.kill()
                    if output == '':
                        if overwrite:
                            os.remove(hdf5_abs_path)
                            os.rename(compressed_hdf5_abs_path,hdf5_abs_path)
                            ret = True
                        else:
                            ret = True
                    if error.find('.'):
                        if error.strip('.') != '':
                            print(error)
        return ret

    @property
    def interxmap_key(self):
        return self._default_interxmap_key





















