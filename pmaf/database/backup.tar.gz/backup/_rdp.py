from Bio import SeqIO
from os import path
import pandas as pd
from ._base import DatabaseBase
from ._meta import DatabasePrimaryWrapperMeta
from pmaf.shared import Consts,SharedMethods
from pmaf.sequence import Nucleotide


class DatabaseRDP(DatabaseBase,DatabasePrimaryWrapperMeta):
    _seq_fasta_headers = ['taxid','species','strain','lineage']
    _database_class_name = 'RDP'
    _sequence_chunk_size = 100
    _inter_index_map_elements = ['taxonomy-map', 'taxonomy-sheet','sequence-accession','sequence-master', 'sequence-aligned']

    def __init__(self, storage_path=None,force_interxmap=False):
     super().__init__()
     self._temp_cache_taxonomy_sheet = None
     self._required_storage_elements = ['taxonomy-map', 'taxonomy-sheet', 'sequence-master', 'sequence-aligned', 'sequence-accession', 'taxonomy-summary']
     self._inter_index_map = None
     if storage_path is not None:
         if not self.load_database_storage(storage_path,force_interxmap):
             raise ValueError('Storage file is invalid.')

    def _init_inter_index_map(self, cached_interxmap=None):
        ret = False
        if self.check_init():
            if cached_interxmap is None:
                tmp_inter_index_map = self._construct_inter_index_map(self.storage_manager)
                if tmp_inter_index_map is not None:
                    self._inter_index_map = tmp_inter_index_map
                    ret = True
            else:
                target_elements = [elem_key for elem_key in self._inter_index_map_elements if self._verify_storage_element(elem_key)]
                if len(target_elements) > 0:
                    if cached_interxmap.columns.isin(target_elements).sum() == len(target_elements):
                        self._inter_index_map = cached_interxmap
                        ret = True
        return ret

    def _get_coordinates_for_element_by_ids(self, element, ids):
        ret = None
        if self._init_state[element]:
            id_list = SharedMethods.ensure_list(ids)
            if len(id_list) > 0:
                if element in self._inter_index_map.columns:
                    tmp_target_index_map = self._inter_index_map.loc[self._inter_index_map.index[self._inter_index_map.index.isin(id_list)], element]
                    ret = pd.Index(tmp_target_index_map.values)
        return ret

    def load_database_storage(self, storage_hdf5_path,force_interxmap=False):
        if self._load_database_storage(storage_hdf5_path, self._database_class_name,force_interxmap):
            return True
        else:
            raise RuntimeError('Cannot load provided storage file. ')

    def build_database_storage(self, storage_hdf5_path,rdp_fasta_filepath_list=[],**kwargs):
        if self._build_database_storage(storage_hdf5_path,rdp_fasta_filepath_list,**kwargs):
            return storage_hdf5_path
        else:
            raise RuntimeError('Cannot create database storage. Check if file already exists.')

    def load_cache_taxonomy_sheet(self):
        ret = False
        tmp_taxonomy_sheet = self._retrieve_taxonomy_sheet()
        if tmp_taxonomy_sheet is not None:
            self._temp_cache_taxonomy_sheet = tmp_taxonomy_sheet
            ret = True
        return ret

    def release_temporary_cache(self):
        self._temp_cache_taxonomy_sheet = None
        return

    def generate_lineages(self, missing_rank=False, desired_ranks=False, drop_ranks=False):
        if self._temp_cache_taxonomy_sheet is not None:
            return SharedMethods.generate_lineages_from_taxa(self._temp_cache_taxonomy_sheet, missing_rank, desired_ranks, drop_ranks)
        else:
            return super().generate_lineages(missing_rank, desired_ranks, drop_ranks)

    def get_taxonomy_by_ids(self, ids):
        ret = False
        if self.is_tax_sheet:
            taxa_ids = SharedMethods.ensure_list(ids)
            if len(taxa_ids) > 0:
                if self.uids.isin(taxa_ids).sum() == len(taxa_ids):
                    if self._temp_cache_taxonomy_sheet is not None:
                        target_taxonomy_df = self._temp_cache_taxonomy_sheet.loc[taxa_ids, :]
                    else:
                        target_taxonomy_df = self._get_taxonomy_sheet_by_ids(taxa_ids)
                    ret = target_taxonomy_df.loc[:, self.get_avail_ranks()]
        return ret

    def get_lingeages_by_ids(self, ids):
        ret = False
        if self.is_tax_sheet:
            taxa_ids = SharedMethods.ensure_list(ids)
            if len(taxa_ids) > 0:
                if self.uids.isin(taxa_ids).sum() == len(taxa_ids):
                    if self._temp_cache_taxonomy_sheet is not None:
                        target_taxonomy_df = self._temp_cache_taxonomy_sheet.loc[taxa_ids, :]
                    else:
                        target_taxonomy_df = self._get_taxonomy_sheet_by_ids(taxa_ids)
                    ret = self.generate_lineages_by_sheet_df(target_taxonomy_df)
        return ret

    def get_sequence_by_ids(self, ids, as_seq=False):
        ret = False
        if self.is_seq:
            taxa_ids = SharedMethods.ensure_list(ids)
            if len(taxa_ids) > 0:
                if self.uids.isin(taxa_ids).sum() == len(taxa_ids):
                    target_sequence_df = self._get_sequence_master_by_ids(taxa_ids)
                    if as_seq:
                        ret = target_sequence_df.apply(lambda seq: Nucleotide(seq['sequence'].upper(), name=seq.name, mode='DNA'), axis=1).to_dict()
                    else:
                        ret = target_sequence_df

        return ret

    def get_sequence_aligned_by_ids(self, ids):
        ret = False
        if self.is_seq_aligned:
            taxa_ids = SharedMethods.ensure_list(ids)
            if len(taxa_ids) > 0:
                if self.uids.isin(taxa_ids).sum() == len(taxa_ids):
                    target_sequence_aligned_df = self._get_sequence_aligned_by_ids(taxa_ids)
                    ret = target_sequence_aligned_df
        return ret

    def get_sequence_acc_by_ids(self, ids):
        ret = False
        if self.is_seq_acc:
            taxa_ids = SharedMethods.ensure_list(ids)
            if len(taxa_ids) > 0:
                if self.uids.isin(taxa_ids).sum() == len(taxa_ids):
                    target_sequence_acc_df = self._get_sequence_accession_by_ids(taxa_ids)
                    ret = target_sequence_acc_df
        return ret

    @classmethod
    def _construct_inter_index_map(cls, storage_manager):
        ret = None
        if storage_manager.check_state():
            target_elements = [elem_key for elem_key in cls._inter_index_map_elements if storage_manager.validate_element_key(elem_key)]
            if len(target_elements) > 0:
                first_element = target_elements[0]
                internal_index_map = storage_manager.get_index_by_element(first_element)
                internal_index_map = internal_index_map.reset_index(name='target').set_index('target').rename({'index': first_element}, axis=1)
                if len(target_elements) > 1:
                    for element in target_elements[1:]:
                        next_elemenet_index_map = storage_manager.get_index_by_element(element)
                        next_elemenet_index_map = next_elemenet_index_map.reset_index(name='target').set_index('target').rename({'index': element}, axis=1)
                        internal_index_map = internal_index_map.join(next_elemenet_index_map, how='left')
                internal_index_map.sort_index(inplace=True)
                internal_index_map.index.rename('index', inplace=True)
                ret = internal_index_map
        return ret

    # Fix parsers so that RDP unaligned genbank sequences would be parsed first and aligned later.
    # @classmethod
    # def _build_database_storage(cls, storage_hdf5_path,rdp_fasta_filepath_list,rdp_aligned_fasta_filepath_list,**kwargs):
        parser_elements = {}
        if all([isinstance(rdp_fasta_filepath, str) for rdp_fasta_filepath in rdp_fasta_filepath_list]):
            if all([path.isfile(rdp_fasta_filepath) for rdp_fasta_filepath in rdp_fasta_filepath_list]):
                parser_elements.update({'pass-dummy-1': {'handle': cls._parse_fasta_headers, 'params': (rdp_fasta_filepath_list,), 'pass': True, 'receive': None}})
                parser_elements.update({'sequence-master': {'handle': cls._parse_sequence_generator, 'params': (rdp_fasta_filepath_list,), 'pass': 2, 'receive': 'pass-dummy-1'}})
                parser_elements.update({'taxonomy-map': {'handle': cls._parse_taxonomy_map, 'params': (), 'pass': 2, 'receive': 'sequence-master'}})
                parser_elements.update({'taxonomy-sheet': {'handle': cls._construct_taxonomy_sheet, 'params': (), 'pass': True, 'receive': 'taxonomy-map'}})
                parser_elements.update({'taxonomy-summary': {'handle': cls._summarize_taxonomy_sheet, 'params': (), 'pass': False, 'receive': 'taxonomy-sheet'}})
        return cls._construct_database_storage(storage_hdf5_path, cls._database_class_name, parser_elements,**kwargs)

    @classmethod
    def _parse_fasta_headers(cls,fasta_filepath_list):
        parsed_headers = {}
        for fasta_filepath in fasta_filepath_list:
            seq_iterator = SeqIO.parse(open(fasta_filepath), 'fasta')
            for seq_record in seq_iterator:
                tmp_seq_headers_dict = {'strain':None,'lineage':None,'species':None,'seq_length':None}
                tmp_seq_headers_dict['seq_length'] = len(seq_record.seq)
                tmp_seq_headers = seq_record.description.split('\t')
                if ';' in tmp_seq_headers[0]:
                    header_taxid_name_strain = tmp_seq_headers[0].split(';')
                    header_taxid_name = header_taxid_name_strain[0]
                    tmp_seq_headers_dict['strain'] = header_taxid_name_strain[1].strip()
                else:
                    header_taxid_name = tmp_seq_headers[0]
                tmp_seq_headers_dict['lineage'] = tmp_seq_headers[1].split('=')[1]
                header_taxid_name_sep_pos = header_taxid_name.find(' ')
                tmp_taxid = header_taxid_name[:header_taxid_name_sep_pos]
                if header_taxid_name_sep_pos != len(header_taxid_name) and header_taxid_name_sep_pos > 0:
                    tmp_seq_headers_dict['species'] = header_taxid_name[header_taxid_name_sep_pos+1:]        
                parsed_headers.update({tmp_taxid:tmp_seq_headers_dict})
        return parsed_headers

    @classmethod
    def _parse_taxonomy_map(cls, parsed_headers_dict):
        tmp_taxonomy_map = pd.DataFrame.from_dict(parsed_headers_dict,orient='index',columns=['lineage','species','strain'])
        taxonomy_map = tmp_taxonomy_map.applymap(lambda x: '' if pd.isna(x) else x)
        return taxonomy_map

    @classmethod
    def _construct_taxonomy_sheet(cls, parsed_headers_dict):
        complete_taxa_dict = {}
        long_ranks = [Consts.ITS['r2rank'][rank] for rank in Consts.MAIN_RANKS]
        for taxid, tax_data in parsed_headers_dict.items():
            tmp_taxa_dict = {rank:None for rank in Consts.MAIN_RANKS}
            lineage_str = tax_data['lineage']
            lineage_split = lineage_str.split(';')
            tmp_taxa_dict['s'] = tax_data['species']
            for rank in long_ranks:
                if rank in lineage_split:
                    rank_index = lineage_split.index(rank)
                    tmp_taxa_dict[Consts.ITS['rank2r'][rank]] = lineage_split[rank_index-1]
            complete_taxa_dict.update({taxid:tmp_taxa_dict})
        tmp_taxonomy_sheet = pd.DataFrame.from_dict(complete_taxa_dict,orient='index',columns=Consts.MAIN_RANKS)
        taxonomy_sheet = tmp_taxonomy_sheet.applymap(lambda x: '' if pd.isna(x) else x)
        return taxonomy_sheet

    @classmethod
    def _parse_sequence_generator(cls,fasta_filepath_list, parsed_headers_dict):
        max_seq_length = max([parsed_seq_elem['seq_length'] for parsed_seq_elem in parsed_headers_dict.values()])
        max_id_length = max([len(taxid) for taxid in parsed_headers_dict.keys()])
        max_rows = len(parsed_headers_dict)
        first_chunk = True
        for fasta_filepath in fasta_filepath_list:
            seq_iterator = SeqIO.parse(open(fasta_filepath), 'fasta')
            chunk_counter = cls._sequence_chunk_size
            next_chunk = True
            while next_chunk:
                sequences_list = []
                for seq_record in seq_iterator:
                    if chunk_counter > 1:
                        sequences_list.append([str(seq_record.id), str(seq_record.seq)])
                        chunk_counter = chunk_counter - 1
                    else:
                        chunk_counter = cls._sequence_chunk_size
                        sequences_list.append([str(seq_record.id), str(seq_record.seq)])
                        break
                if len(sequences_list) > 0:
                    chunk_df = pd.DataFrame.from_records(sequences_list, columns=['index', 'sequence'], index=['index'])
                    if first_chunk:
                        first_chunk = False
                        pre_state_dict = {'index': max_id_length, 'sequence': max_seq_length, 'max_rows': max_rows}
                        yield pre_state_dict, chunk_df
                    else:
                        yield chunk_df
                else:
                    next_chunk = False
        return

    @classmethod
    def _summarize_taxonomy_sheet(cls, master_taxonomy_sheet):
        database_summary = {}
        master_taxonomy_sheet.loc[:, Consts.MAIN_RANKS] = master_taxonomy_sheet.loc[:, Consts.MAIN_RANKS].applymap(lambda x: None if (x == '') else x)
        avail_ranks = [rank for rank in Consts.MAIN_RANKS if master_taxonomy_sheet.loc[:, rank].notna().any()]
        master_taxonomy_sheet.loc[:, 'lineage'] = SharedMethods.generate_lineages_from_taxa(master_taxonomy_sheet, True, avail_ranks, False)
        database_summary.update({'available-ranks': ','.join(avail_ranks)})

        total_taxa = master_taxonomy_sheet.shape[0]
        database_summary.update({'total-taxa': str(total_taxa)})

        total_duplicated_taxa = master_taxonomy_sheet[master_taxonomy_sheet.duplicated(subset=['lineage'], keep=False)].drop_duplicates(subset=['lineage']).reset_index(drop=True).shape[0]
        database_summary.update({'total-duplicated-taxa': str(total_duplicated_taxa)})

        total_unduplicated_taxa = master_taxonomy_sheet.drop_duplicates(subset=['lineage']).reset_index(drop=True).shape[0]
        database_summary.update({'total-unduplicated-taxa': str(total_unduplicated_taxa)})

        total_unique_taxa = master_taxonomy_sheet[~master_taxonomy_sheet.duplicated(subset=['lineage'], keep=False)].shape[0]
        database_summary.update({'total-unique-taxa': str(total_unique_taxa)})

        def summarize_for_rank(rank):
            if rank in avail_ranks:
                total = master_taxonomy_sheet[master_taxonomy_sheet[rank].notna()][rank]
                duplicated = total.duplicated(keep=False)
                unique = total[~duplicated].dropna()
                count_shared = 0
                if rank in avail_ranks:
                    prior_ranks = SharedMethods.get_rank_upto(avail_ranks, rank)
                    if prior_ranks:
                        filter_dup = master_taxonomy_sheet[master_taxonomy_sheet.duplicated(subset=[rank], keep=False)].dropna(subset=[rank])[avail_ranks].drop_duplicates(subset=prior_ranks)
                        count_shared = filter_dup[filter_dup.duplicated(subset=rank, keep=False)].reset_index(drop=True).shape[0]
                count_total = total.shape[0]
                count_duplicated = sum(duplicated)
                count_unique = unique.shape[0]

                return {'total': str(count_total), 'duplicated': str(count_duplicated), 'unique': str(count_unique), 'shared-with-other-taxa': str(count_shared)}
            else:
                return {'total': str(0), 'duplicated': str(0), 'unique': str(0), 'shared-with-other-taxa': str(0)}

        for rank in Consts.MAIN_RANKS:
            rank_name_full = Consts.ITS['r2rank'][rank]
            summary = summarize_for_rank(rank)
            database_summary.update({'{}-total'.format(rank_name_full): summary['total']})
            database_summary.update({'{}-duplicated'.format(rank_name_full): summary['duplicated']})
            database_summary.update({'{}-unique'.format(rank_name_full): summary['unique']})
            database_summary.update({'{}-shared'.format(rank_name_full): summary['shared-with-other-taxa']})

        summary_series = pd.Series(database_summary).map(str)
        return summary_series

    @property
    def _storage_elements(self):
        return self._required_storage_elements

    @property
    def name(self):
        return self._database_class_name

    @property
    def sequence_accession(self):
        if self.is_seq_acc:
            return self._retrieve_sequence_accession()
        else:
            return None

    @property
    def taxonomy_sheet(self):
        if self.is_tax_sheet:
            if self._temp_cache_taxonomy_sheet is None:
                return self._retrieve_taxonomy_sheet()
            else:
                return self._temp_cache_taxonomy_sheet
        else:
            return None

    @property
    def taxonomy_map(self):
        return self._retrieve_taxonomy_map()
