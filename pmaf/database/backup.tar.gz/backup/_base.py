from pmaf.shared import SharedMethods
from pmaf.shared import Consts
from pmaf.phylo.tree import Tree
from ._meta import DatabaseBaseMeta
from ._storage_manager import DatabaseStorageManager
import pickle, datetime, random, copy, ete3
from os import path
import pandas as pd


class DatabaseBase(DatabaseBaseMeta):
    def __init__(self):
        self._storage_manager = None
        self._default_cache_index = None
        self._default_cache_summary = None
        self._default_cache_avail_ranks = None
        self._closed_state = False
        self._init_state = {'tree-parsed':False,
                            'tree-object':False,
                            'tree-map':False,
                            'taxonomy-map':False,
                            'taxonomy-sheet':False,
                            'sequence-master':False,
                            'sequence-aligned':False,
                            'sequence-accession': False,
                            'taxonomy-summary':False}

    def __repr__(self):
        class_name = self.__class__.__name__
        if not self._closed_state:
            ranks = ','.join(self._default_cache_avail_ranks) if self._default_cache_avail_ranks is not None else 'N/A'
            total_taxa = str(self._default_cache_summary['total-taxa']) if self._default_cache_summary is not None else 'N/A'
            tax_state = ''.join(['+' if state_elem else '-' for state_elem in [self._init_state['taxonomy-sheet'], self._init_state['taxonomy-map']]])
            tree_state = ''.join(['+' if state_elem else '-' for state_elem in [self._init_state['tree-parsed'],self._init_state['tree-object'],self._init_state['tree-map']]])
            seq_state = ''.join(['+' if state_elem else '-' for state_elem in [self._init_state['sequence-master'], self._init_state['sequence-aligned'],self._init_state['sequence-accession']]])
            repr_str = "<{}:[{}]:[{}]: Taxonomy:[{}], Sequence:[{}], Tree:[{}]>".format(class_name, total_taxa, ranks, tax_state, seq_state, tree_state)
        else:
            repr_str = "<{}:[Closed Database]>".format(class_name)
        return repr_str

    def check_init(self):
        ret = False
        primary_elements = [elem_state for elem_key,elem_state in self._init_state.items() if elem_key in self._storage_elements]
        if any(primary_elements):
            ret = True
        return ret

    def _verify_element_state(self,element):
        return self._init_state[element]

    def close(self):
        self._storage_manager.shutdown_manager()
        self._default_cache_index = None
        self._default_cache_summary = None
        self._default_cache_avail_ranks = None
        for elem_key in self._init_state.keys():
            self._init_state[elem_key] = False
        self._closed_state = True
        return

    @classmethod
    def _construct_database_storage(cls,hdf5_filepath,database_name,parser_elements,**kwargs):
        ret = False
        force = False
        compress = False
        overwrite = True
        cache_interxmap = False
        complevel = 9
        complib = 'blosc'
        if len(kwargs):
            for key,value in kwargs.items():
                if key == 'force' and isinstance(value,bool):
                    force = value
                elif key == 'compress' and isinstance(value,bool):
                    compress = value
                elif key == 'overwrite' and isinstance(value,bool):
                    overwrite = value
                elif key == 'complevel' and isinstance(value,int):
                    complevel = value
                elif key == 'complib' and isinstance(value,str):
                    complib = value
                elif key == 'cache_interxmap' and isinstance(value,bool):
                    cache_interxmap = value
                else:
                    raise ValueError('Invalid parameters were provided.')
        if DatabaseStorageManager.validate_parser_elements(parser_elements):
            tmp_storage = DatabaseStorageManager(hdf5_filepath,database_name,force_new=force)
            if tmp_storage.assign_parser_elements(parser_elements):
                if tmp_storage.commit_to_storage():
                    if cache_interxmap:
                        if tmp_storage.reset_internals():
                            interxmap = cls._construct_inter_index_map(tmp_storage)
                            if interxmap is not None:
                                if not tmp_storage.put_interxmap_to_storage(interxmap):
                                    raise RuntimeError('Error occured during commiting interxmap to storage.')
                            else:
                                raise RuntimeError('Error. Inter index map was not constructed.')
                        else:
                            raise RuntimeError('Error. Cannot initiate storage manager internal elements.')
                    if tmp_storage.shutdown_manager():
                        if compress:
                            if tmp_storage.compress_storage(complevel=complevel,complib=complib,overwrite=overwrite):
                                ret = True
                        else:
                            ret = True
        return ret

    def _load_database_storage(self, hdf5_filepath,database_name,force_new_interxmap):
        ret = False
        if isinstance(hdf5_filepath,str):
            if len(hdf5_filepath)>0:
                if path.isfile(hdf5_filepath):
                    if DatabaseStorageManager.validate_storage(hdf5_filepath,database_name):
                        tmp_storage_manager = DatabaseStorageManager(hdf5_filepath,database_name,reset_internals=True)
                        if tmp_storage_manager.check_state():
                            self._storage_manager = tmp_storage_manager
                            if tmp_storage_manager.validate_element_key(tmp_storage_manager.interxmap_key):
                                interxmap = None if force_new_interxmap else tmp_storage_manager.retrieve_interxmap_from_storage()
                            else:
                                interxmap = None
                            if self._init_internals(interxmap):
                                ret = True
        return ret

    def _init_internals(self,cached_interxmap=None):
        ret = False
        valid_elements = [elem_key for elem_key in self._storage_elements if self._storage_manager.validate_element_key(elem_key)]
        if len(valid_elements)>0:
            for element in valid_elements:
                self._init_state[element] = True
            if self._init_state['taxonomy-map']:
                tmp_uid_coord = self._storage_manager.get_index_by_element('taxonomy-map')
                if tmp_uid_coord is not None:
                    tmp_index = pd.Index(tmp_uid_coord.values)
                    self._default_cache_index = tmp_index
                    store_handle = self._storage_manager.get_handle_by_element('taxonomy-summary')
                    if store_handle:
                        tmp_summary = store_handle.select(Consts.DATABASE_HDF5_STRUCT['taxonomy-summary'])
                        if tmp_summary is not None:
                            self._default_cache_summary = tmp_summary
                            tmp_avail_ranks = tmp_summary['available-ranks'].split(',')
                            tmp_avail_ranks_sorted = [rank for rank in Consts.MAIN_RANKS if rank in tmp_avail_ranks]
                            if len(tmp_avail_ranks_sorted)>0:
                                self._default_cache_avail_ranks = tmp_avail_ranks_sorted
                                if self._init_inter_index_map(cached_interxmap):
                                    ret = True
        return ret

    def _verify_storage_element(self,element):
        return self._storage_manager.validate_element_key(element)

    def _retrieve_index_by_element(self,element):
        return self._storage_manager.get_index_by_element(element)

    def _retrieve_taxonomy_summary(self):
        ret = None
        if self._init_state['taxonomy-summary']:
            store_handle = self._storage_manager.get_handle_by_element('taxonomy-summary')
            content = store_handle.select(Consts.DATABASE_HDF5_STRUCT['taxonomy-summary'])
            ret = self._map_missing_as_nan(content)
        return ret

    def _retrieve_taxonomy_sheet(self):
        ret = None
        if self._init_state['taxonomy-sheet']:
            store_handle = self._storage_manager.get_handle_by_element('taxonomy-sheet')
            content = store_handle.select(Consts.DATABASE_HDF5_STRUCT['taxonomy-sheet'])
            ret = self._map_missing_as_nan(content)
        return ret

    def _retrieve_taxonomy_map(self):
        ret = None
        if self._init_state['taxonomy-map']:
            store_handle = self._storage_manager.get_handle_by_element('taxonomy-map')
            content = store_handle.select(Consts.DATABASE_HDF5_STRUCT['taxonomy-map'])
            ret = self._map_missing_as_nan(content)
        return ret

    def _retrieve_sequence_master(self):
        ret = None
        if self._init_state['sequence-master']:
            store_handle = self._storage_manager.get_handle_by_element('sequence-master')
            content = store_handle.select(Consts.DATABASE_HDF5_STRUCT['sequence-master'])
            ret = self._map_missing_as_nan(content)
        return ret

    def _retrieve_sequence_aligned(self):
        ret = None
        if self._init_state['sequence-aligned']:
            store_handle = self._storage_manager.get_handle_by_element('sequence-aligned')
            content = store_handle.select(Consts.DATABASE_HDF5_STRUCT['sequence-aligned'])
            ret = self._map_missing_as_nan(content)
        return ret

    def _retrieve_sequence_accession(self):
        ret = None
        if self._init_state['sequence-accession']:
            store_handle = self._storage_manager.get_handle_by_element('sequence-accession')
            content = store_handle.select(Consts.DATABASE_HDF5_STRUCT['sequence-accession'])
            ret = self._map_missing_as_nan(content)
        return ret

    def _retrieve_tree_map(self):
        ret = None
        if self._init_state['tree-map']:
            store_handle = self._storage_manager.get_handle_by_element('tree-map')
            content = store_handle.select(Consts.DATABASE_HDF5_STRUCT['tree-map'])
            ret = self._map_missing_as_nan(content)
        return ret

    def _retrieve_tree_parsed(self):
        ret = None
        if self._init_state['tree-parsed']:
            store_handle = self._storage_manager.get_handle_by_element('tree-parsed')
            ret = store_handle.get_node(Consts.DATABASE_HDF5_STRUCT['tree-parsed']).read()[0]
        return ret

    def _retrieve_tree_object(self):
        ret = None
        if self._init_state['tree-object']:
            store_handle = self._storage_manager.get_handle_by_element('tree-object')
            ret = store_handle.get_node(Consts.DATABASE_HDF5_STRUCT['tree-object']).read()[0]
        return ret

    def _get_taxonomy_sheet_by_ids(self, ids):
        ret = None
        coord = self._get_coordinates_for_element_by_ids('taxonomy-sheet',ids)
        if coord is not None:
            store_handle = self._storage_manager.get_handle_by_element('taxonomy-sheet')
            content = store_handle.select(Consts.DATABASE_HDF5_STRUCT['taxonomy-sheet'],coord)
            ret = self._map_missing_as_nan(content)
        return ret

    def _get_taxonomy_map_by_ids(self, ids):
        ret = None
        coord = self._get_coordinates_for_element_by_ids('taxonomy-map', ids)
        if coord is not None:
            store_handle = self._storage_manager.get_handle_by_element('taxonomy-map')
            content = store_handle.select(Consts.DATABASE_HDF5_STRUCT['taxonomy-map'], coord)
            ret = self._map_missing_as_nan(content)
        return ret

    def _get_sequence_master_by_ids(self, ids):
        ret = None
        coord = self._get_coordinates_for_element_by_ids('sequence-master', ids)
        if coord is not None:
            store_handle = self._storage_manager.get_handle_by_element('sequence-master')
            content = store_handle.select(Consts.DATABASE_HDF5_STRUCT['sequence-master'], coord)
            ret = self._map_missing_as_nan(content)
        return ret

    def _get_sequence_aligned_by_ids(self, ids):
        ret = None
        coord = self._get_coordinates_for_element_by_ids('sequence-aligned', ids)
        if coord is not None:
            store_handle = self._storage_manager.get_handle_by_element('sequence-aligned')
            content = store_handle.select(Consts.DATABASE_HDF5_STRUCT['sequence-aligned'], coord)
            ret = self._map_missing_as_nan(content)
        return ret

    def _get_sequence_accession_by_ids(self, ids):
        ret = None
        coord = self._get_coordinates_for_element_by_ids('sequence-accession', ids)
        if coord is not None:
            store_handle = self._storage_manager.get_handle_by_element('sequence-accession')
            content = store_handle.select(Consts.DATABASE_HDF5_STRUCT['sequence-accession'], coord)
            ret = self._map_missing_as_nan(content)
        return ret

    def generate_lineages(self, missing_rank=False, desired_ranks=False, drop_ranks=False):  # iMissingRank - if True will include rank preffix(such as "s__") even if rank is missing or among iDropRanks; iDesiredRanks - list of desired ranks; iDropRanks - list of undesired ranks that should be removed, this parameter is useless if iMissingRank is set to False
        return SharedMethods.generate_lineages_from_taxa(self._retrieve_taxonomy_sheet(), missing_rank, desired_ranks,drop_ranks)

    def generate_lineages_by_sheet_df(self,sheet_df, missing_rank=True, drop_ranks=False):
        return SharedMethods.generate_lineages_from_taxa(sheet_df,missing_rank,self.get_avail_ranks(),drop_ranks)

    def get_avail_ranks(self):
        return self._default_cache_avail_ranks

    def _request_loaded_tree_object(self):
        ret = False
        tree_object_bytes = self._retrieve_tree_object()
        if tree_object_bytes is not None:
            ret = Tree(pickle.loads(tree_object_bytes),'object')
        return ret

    def prune_tree_by_ids(self, tip_ids):
        ret = False
        if self._verify_element_state('tree-object'):
            id_list = SharedMethods.ensure_list(tip_ids)
            if len(id_list)>0:
                if self._default_cache_index.isin(id_list).sum() == len(id_list):
                    tmp_tree_object = self._request_loaded_tree_object()
                    if tmp_tree_object:
                        tmp_tree_object.prune_for_ids(id_list)
                        ret = tmp_tree_object
        return ret

    def infer_topology_by_ids(self, tip_ids):
        ret = False
        if self._verify_element_state('tree-map'):
            if len(tip_ids) > 0:
                tree_map = self._retrieve_tree_map()
                tree_map = self._map_missing_as_nan(tree_map)
                non_roots_indices = tree_map[tree_map['pid'].notna()].index
                top_level_uid = tree_map[~tree_map.index.isin(non_roots_indices)].index.values.tolist()[0]
                if tree_map is not None:
                    taxon_level = 1
                    pid_map_df = tree_map.loc[tip_ids]['pid'].reset_index().reindex(columns=['pid', 'uid']).rename(columns={'pid': taxon_level, 'uid': 0})
                    top_level = False
                    while not top_level:
                        taxon_level = taxon_level + 1
                        tmp_level_map = tree_map.loc[pid_map_df[taxon_level - 1]]['pid']
                        if tmp_level_map.isna().any():
                            tmp_level_map.fillna(top_level_uid, inplace=True)
                        pid_map_df.set_index(taxon_level - 1, inplace=True)
                        tmp_level_map.rename(taxon_level, inplace=True)
                        pid_map_df.loc[:, taxon_level] = tmp_level_map
                        pid_map_df.reset_index(inplace=True)
                        if tmp_level_map.nunique() == 1:
                            if tmp_level_map.iloc[0] == top_level_uid:
                                top_level = True
                    pid_map_df = pid_map_df.reindex(sorted(pid_map_df.columns, reverse=True), axis=1)
                    pid_map_df = pid_map_df.applymap(lambda node: "'{}'".format(node))
                    pid_map_df.drop(taxon_level, axis=1, inplace=True)
                    lineage_map_list = pid_map_df.values.tolist()
                    lineage_map_list_fixed = []
                    for lineage_map_list_elem in lineage_map_list:
                        taxon_elem_seen = set()
                        tmp_lineage_map_list_elem_unique_ordered = [elem for elem in lineage_map_list_elem if not (
                                    elem in taxon_elem_seen or taxon_elem_seen.add(elem))]
                        lineage_map_list_fixed.append(tmp_lineage_map_list_elem_unique_ordered)
                    root_node_name = "'{}'".format(top_level_uid)
                    tmp_tree = ete3.Tree(name=root_node_name)

                    for tip_lineage_map in lineage_map_list_fixed:
                        last_node = tmp_tree
                        for lineage_taxon_name in tip_lineage_map:
                            existing_nodes = tmp_tree.search_nodes(name=lineage_taxon_name)
                            if len(existing_nodes) > 0:
                                last_node = existing_nodes[0]
                            else:
                                last_node = last_node.add_child(name=lineage_taxon_name)

                    tip_name_list_quoted = ["'{}'".format(name) for name in tip_ids]
                    tmp_tree.prune(tip_name_list_quoted, preserve_branch_length=True)
                    ret = Tree(tmp_tree,'object')
        return ret

    # This method sets taxons with "" = None. For example, lineages sometimes contain ranks such as (...; g__; s__) and (...; g__;). If consensus lineages are only available taxonomic information then such taxa are basically same and must be fixed.
    @staticmethod
    def _map_missing_as_nan(target_pd_object):
        if isinstance(target_pd_object,pd.DataFrame):
            return target_pd_object.applymap(lambda x: None if (x == '' or pd.isna(x)) else x)
        else:
            return target_pd_object.map(lambda x: None if (x == '' or pd.isna(x)) else x)

    @property
    def uids(self):
        ret = None
        if self.check_init():
            ret = self._default_cache_index
        return ret

    @property
    def taxonomy_summary(self):
        return self._default_cache_summary

    @property
    def state(self):
        return self.check_init()

    @property
    def storage_manager(self):
        return self._storage_manager

    @property
    def is_seq(self):
        return self._verify_element_state('sequence-master')

    @property
    def is_seq_aligned(self):
        return self._verify_element_state('sequence-aligned')

    @property
    def is_seq_acc(self):
        return self._verify_element_state('sequence-accession')

    @property
    def is_tax_map(self):
        return self._verify_element_state('taxonomy-map')

    @property
    def is_tax_sheet(self):
        return self._verify_element_state('taxonomy-sheet')

    @property
    def is_tree_map(self):
        return self._verify_element_state('tree-map')

    @property
    def is_tree_parsed(self):
        return self._verify_element_state('tree-parsed')

    @property
    def is_tree_object(self):
        return self._verify_element_state('tree-object')




