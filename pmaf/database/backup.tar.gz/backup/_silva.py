from random import random
from Bio import SeqIO
from os import path
from tempfile import NamedTemporaryFile
import collections
import csv
import ete3
import pandas as pd
from pmaf.database._base import DatabaseBase
from pmaf.database._meta import DatabasePrimaryWrapperMeta
from pmaf.shared import Consts,SharedMethods
from pmaf.sequence import Nucleotide, MultiSequence,MultiSeqStream


class DatabaseSILVA(DatabaseBase,DatabasePrimaryWrapperMeta):
    _tax_map_csv_delimiter = '\t'
    _tax_map_csv_quote = '"'
    _seq_map_fasta_headers = ['description','sequence']
    _database_class_name = 'SILVA'
    _sequence_chunk_size = 100
    _inter_index_map_elements = ['taxonomy-map', 'taxonomy-sheet','sequence-accession','sequence-master', 'sequence-aligned']

    def __init__(self, storage_path=None,force_interxmap=False):
     super().__init__()
     self._temp_cache_taxonomy_sheet = None
     self._required_storage_elements = ['tree-parsed', 'tree-object', 'tree-map', 'taxonomy-map', 'taxonomy-sheet', 'sequence-master', 'sequence-aligned', 'sequence-accession', 'taxonomy-summary']
     self._inter_index_map = None
     if storage_path is not None:
         if not self.load_database_storage(storage_path,force_interxmap):
             raise ValueError('Storage file is invalid.')

    def _init_inter_index_map(self,cached_interxmap=None):
        ret = False
        if self.check_init():
            if cached_interxmap is None:
                tmp_inter_index_map = self._construct_inter_index_map(self.storage_manager)
                if tmp_inter_index_map is not None:
                    self._inter_index_map = tmp_inter_index_map
                    ret = True
            else:
                target_elements = [elem_key for elem_key in self._inter_index_map_elements if self._verify_storage_element(elem_key)]
                if len(target_elements) > 0:
                    if cached_interxmap.columns.isin(target_elements).sum() == len(target_elements):
                        self._inter_index_map = cached_interxmap
                        ret = True
        return ret

    def _get_coordinates_for_element_by_ids(self, element, ids):
        ret = None
        if self._init_state[element]:
            id_list = list(map(str,SharedMethods.ensure_list(ids)))
            if len(id_list) > 0:
                if element in self._inter_index_map.columns:
                    if element.startswith('sequence-'):
                        acc_numbers_list = self._inter_index_map[element][id_list].apply(lambda x:  x.split('|')).tolist()
                        acc_numbers_flat = [int(acc_pos) for acc_pos_list in acc_numbers_list for acc_pos in acc_pos_list]
                        ret = pd.Index(acc_numbers_flat)
                    else:
                        tmp_target_index_map = self._inter_index_map.loc[self._inter_index_map.index[self._inter_index_map.index.isin(id_list)], element]
                        ret = pd.Index(tmp_target_index_map.values)
        return ret

    def load_database_storage(self, storage_hdf5_path,force_interxmap=False):
        if self._load_database_storage(storage_hdf5_path, self._database_class_name,force_interxmap):
            return True
        else:
            raise RuntimeError('Cannot load provided storage file. ')

    def build_database_storage(self, storage_hdf5_path, taxonomy_map_csv_path, tree_newick_path=None, sequence_fasta_path=None, sequence_aligned_path=None,sequence_accession_path=None,**kwargs):
        if self._build_database_storage(storage_hdf5_path, taxonomy_map_csv_path, tree_newick_path, sequence_fasta_path, sequence_aligned_path,sequence_accession_path,**kwargs):
            return storage_hdf5_path
        else:
            raise RuntimeError('Cannot create database storage. Check if file already exists.')

    def load_cache_taxonomy_sheet(self):
        ret = False
        tmp_taxonomy_sheet = self._retrieve_taxonomy_sheet()
        if tmp_taxonomy_sheet is not None:
            self._temp_cache_taxonomy_sheet = tmp_taxonomy_sheet
            ret = True
        return ret

    def release_temporary_cache(self):
        self._temp_cache_taxonomy_sheet = None
        return

    def generate_lineages(self, missing_rank=False, desired_ranks=False, drop_ranks=False):
        if self._temp_cache_taxonomy_sheet is not None:
            return SharedMethods.generate_lineages_from_taxa(self._temp_cache_taxonomy_sheet, missing_rank, desired_ranks, drop_ranks)
        else:
            return super().generate_lineages(missing_rank, desired_ranks, drop_ranks)

    def get_taxonomy_by_ids(self, ids):
        ret = False
        if self.is_tax_sheet:
            taxa_ids = SharedMethods.ensure_list(ids)
            if len(taxa_ids) > 0:
                if self.uids.isin(taxa_ids).sum() == len(taxa_ids):
                    if self._temp_cache_taxonomy_sheet is not None:
                        target_taxonomy_df = self._temp_cache_taxonomy_sheet.loc[taxa_ids, :]
                    else:
                        target_taxonomy_df = self._get_taxonomy_sheet_by_ids(taxa_ids)
                    ret = target_taxonomy_df.loc[:, self.get_avail_ranks()]
        return ret

    def get_lingeages_by_ids(self, ids):
        ret = False
        if self.is_tax_sheet:
            taxa_ids = SharedMethods.ensure_list(ids)
            if len(taxa_ids) > 0:
                if self.uids.isin(taxa_ids).sum() == len(taxa_ids):
                    if self._temp_cache_taxonomy_sheet is not None:
                        target_taxonomy_df = self._temp_cache_taxonomy_sheet.loc[taxa_ids, :]
                    else:
                        target_taxonomy_df = self._get_taxonomy_sheet_by_ids(taxa_ids)
                    ret = self.generate_lineages_by_sheet_df(target_taxonomy_df)
        return ret

    def get_sequence_by_ids(self, ids,stream=False):
        ret = False
        if self.is_seq:
            taxa_ids = SharedMethods.ensure_list(ids)
            if len(taxa_ids) > 0:
                if self.uids.isin(taxa_ids).sum() == len(taxa_ids):
                    tmp_acc_df = self._get_sequence_accession_by_ids(ids)
                    tmp_acc_series = tmp_acc_df['taxid']
                    tmp_seq_series = tmp_acc_series.groupby(tmp_acc_series).apply(lambda group: group.index)
                    if not stream:
                        target_sequence_df = self._get_sequence_master_by_ids(ids)
                        target_sequence_dict = {}
                        for taxid, acc_nums in tmp_seq_series.iteritems():
                            tmp_sequences_list = target_sequence_df.loc[acc_nums, :].apply(lambda seq: Nucleotide(seq['sequence'], name=seq.name, metadata={'description': seq['description'], 'taxid': taxid}, mode='RNA'), axis=1).values.tolist()
                            tmp_multiseq = MultiSequence(tmp_sequences_list, name=taxid, internal_id='taxid', metadata={'accession-numbers':'; '.join(acc_nums.values.tolist())})
                            target_sequence_dict.update({taxid: tmp_multiseq})
                        ret = target_sequence_dict
                    else:
                        target_sequence_dict = {}
                        for taxid, acc_nums in tmp_seq_series.iteritems():
                            target_sequence_df = self._get_sequence_master_by_ids(taxid)
                            tmp_sequences_list = target_sequence_df.loc[acc_nums, :].apply(lambda seq: Nucleotide(seq['sequence'], name=seq.name, metadata={'description': seq['description'], 'taxid': taxid}, mode='RNA'), axis=1).values.tolist()
                            tmp_seq_stream = MultiSeqStream(name=taxid,mode='RNA',expected_rows=len(acc_nums))
                            tmp_seq_stream.extend_multiseq(MultiSequence(tmp_sequences_list, name=taxid, internal_id='taxid', metadata={'accession-numbers':'; '.join(acc_nums.values.tolist())}))
                            target_sequence_dict.update({taxid: tmp_seq_stream})
                        ret = target_sequence_dict
        return ret

    def get_sequence_aligned_by_ids(self, ids,stream=False):
        ret = False
        if self.is_seq_aligned:
            taxa_ids = SharedMethods.ensure_list(ids)
            if len(taxa_ids) > 0:
                if self.uids.isin(taxa_ids).sum() == len(taxa_ids):
                    tmp_acc_df = self._get_sequence_accession_by_ids(ids)
                    tmp_acc_series = tmp_acc_df['taxid']
                    tmp_seq_aligned_series = tmp_acc_series.groupby(tmp_acc_series).apply(lambda group: group.index)
                    if not stream:
                        target_sequence_aligned_df = self._get_sequence_aligned_by_ids(ids)
                        target_sequence_dict = {}
                        for taxid, acc_nums in tmp_seq_aligned_series.iteritems():
                            tmp_sequences_aligned_list = target_sequence_aligned_df.loc[acc_nums, :].apply(lambda seq: Nucleotide(seq['sequence'], name=seq.name, metadata={'description': seq['description'], 'taxid': taxid}, mode='RNA'), axis=1).values.tolist()
                            tmp_multiseq = MultiSequence(tmp_sequences_aligned_list, name=taxid, internal_id='taxid',aligned=True, metadata={'accession-numbers':'; '.join(acc_nums.values.tolist())})
                            target_sequence_dict.update({taxid: tmp_multiseq})
                        ret = target_sequence_dict
                    else:
                        target_sequence_dict = {}
                        for taxid, acc_nums in tmp_seq_aligned_series.iteritems():
                            target_sequence_aligned_df = self._get_sequence_aligned_by_ids(ids)
                            tmp_sequences_aligned_list = target_sequence_aligned_df.loc[acc_nums, :].apply(lambda seq: Nucleotide(seq['sequence'], name=seq.name, metadata={'description': seq['description'], 'taxid': taxid}, mode='RNA'), axis=1).values.tolist()
                            tmp_seq_stream = MultiSeqStream(name=taxid,mode='RNA',aligned=True,expected_rows=len(acc_nums))
                            tmp_seq_stream.extend_multiseq(MultiSequence(tmp_sequences_aligned_list, name=taxid, internal_id='taxid',aligned=True, metadata={'accession-numbers':'; '.join(acc_nums.values.tolist())}))
                            target_sequence_dict.update({taxid: tmp_seq_stream})
                        ret = target_sequence_dict
        return ret

    def get_sequence_acc_by_ids(self, ids):
        ret = False
        if self.is_seq_acc:
            taxa_ids = SharedMethods.ensure_list(ids)
            if len(taxa_ids) > 0:
                if self.uids.isin(taxa_ids).sum() == len(taxa_ids):
                    tmp_acc_df = self._get_sequence_accession_by_ids(ids)
                    tmp_acc_series = tmp_acc_df['taxid']
                    ret = tmp_acc_series.groupby(tmp_acc_series).apply(lambda group: group.index.values)
        return ret

    @classmethod
    def _construct_inter_index_map(cls, storage_manager):
        ret = None
        if storage_manager.check_state():
            target_elements = [elem_key for elem_key in cls._inter_index_map_elements if storage_manager.validate_element_key(elem_key)]
            if len(target_elements)>0:
                internal_index_map = None
                taxid_acc_map_dict = None
                seq_elements = {elem_key: target_elements.index(elem_key) for elem_key in target_elements if elem_key.startswith('sequence')}
                if len(seq_elements) > 0 and 'sequence-accession' in seq_elements.keys():
                    acc_index = seq_elements.pop('sequence-accession')
                    first_seq_index = min(seq_elements.values())
                    if acc_index > first_seq_index:
                        target_elements.pop(acc_index)
                        target_elements.insert(first_seq_index, 'sequence-accession')
                for element in target_elements:
                    coord_series = None
                    if element == 'sequence-accession':
                        store_handle = storage_manager.get_handle_by_element('sequence-accession')
                        content = store_handle.select(Consts.DATABASE_HDF5_STRUCT['sequence-accession'])
                        taxid_acc_map = cls._map_missing_as_nan(content)
                        taxid_acc_map_dict = taxid_acc_map['taxid'].to_dict()
                        tmp_coord_series = storage_manager.get_index_by_element(element)
                        acc_coord_series = tmp_coord_series.map(taxid_acc_map_dict.get)
                        # Based on http://www.insdc.org/files/feature_table.html accession number naming convention `\` character is forbidden. Hence, accession numbers can be separated by `\` character and stored efficiently in inter index map dataframe
                        coord_series = acc_coord_series.groupby(acc_coord_series).apply(lambda group: '|'.join(group.index.astype(str).tolist())).to_frame(name=element)
                    elif element in ['sequence-master', 'sequence-aligned'] and taxid_acc_map_dict is not None:
                        tmp_coord_series = storage_manager.get_index_by_element(element)
                        seq_coord_series = tmp_coord_series.map(taxid_acc_map_dict.get)
                        coord_series = seq_coord_series.groupby(seq_coord_series).apply(lambda group: '|'.join(group.index.astype(str).tolist())).to_frame(name=element)
                    else:
                        tmp_coord_series = storage_manager.get_index_by_element(element)
                        coord_series = tmp_coord_series.reset_index(name='target').set_index('target').rename({'index': element}, axis=1)
                    if internal_index_map is None:
                        internal_index_map = coord_series
                    else:
                        internal_index_map = internal_index_map.join(coord_series, how='left')
                internal_index_map = internal_index_map.sort_index().applymap(lambda value: '' if pd.isna(value) else value)
                internal_index_map.index.rename('index', inplace=True)
                ret = internal_index_map
        return ret

    @classmethod
    def _build_database_storage(cls, storage_hdf5_path, taxonomy_map_csv_path, tree_newick_path, sequence_fasta_path, sequence_aligned_path,sequence_accession_path,**kwargs):
        parser_elements = {}
        if isinstance(taxonomy_map_csv_path, str):
            if path.isfile(taxonomy_map_csv_path):
                parser_elements.update({'taxonomy-map': {'handle': cls._parse_taxonomy_map, 'params': (taxonomy_map_csv_path,), 'pass': True, 'receive': None}})
                parser_elements.update({'taxonomy-sheet': {'handle': cls._construct_taxonomy_sheet, 'params': (), 'pass': True, 'receive': 'taxonomy-map'}})
                parser_elements.update({'taxonomy-summary': {'handle': cls._summarize_taxonomy_sheet, 'params': (), 'pass': False, 'receive': 'taxonomy-sheet'}})
        if isinstance(tree_newick_path, str):
            if path.isfile(tree_newick_path):
                parser_elements.update({'tree-object': {'handle': cls._make_tree_from_newick, 'params': (tree_newick_path,), 'pass': True, 'receive': None}})
                parser_elements.update({'pass-dummy-1': {'handle': cls._rebuild_and_transform_from_tree_object, 'params': (), 'pass': True, 'receive': 'tree-object'}})
                parser_elements.update({'tree-parsed': {'handle': cls._transform_tree_to_newick, 'params': (), 'pass': 2, 'receive': 'pass-dummy-1'}})
                parser_elements.update({'tree-map': {'handle': cls._transformed_tree_to_map, 'params': (), 'pass': False, 'receive': 'tree-parsed'}})
        if isinstance(sequence_fasta_path, str):
            if path.isfile(sequence_fasta_path):
                parser_elements.update({'sequence-master': {'handle': cls._parse_sequence_generator, 'params': (sequence_fasta_path,), 'pass': False, 'receive': None}})
        if isinstance(sequence_aligned_path, str):
            if path.isfile(sequence_aligned_path):
                parser_elements.update({'sequence-aligned': {'handle': cls._parse_sequence_generator, 'params': (sequence_aligned_path,), 'pass': False, 'receive': None}})
        if isinstance(sequence_accession_path, str):
            if path.isfile(sequence_accession_path):
                parser_elements.update({'sequence-accession': {'handle': cls._parse_sequence_accessions, 'params': (sequence_accession_path,), 'pass': False, 'receive': None}})
        return cls._construct_database_storage(storage_hdf5_path, cls._database_class_name, parser_elements,**kwargs)

    @classmethod
    def _parse_taxonomy_map(cls, taxonomy_map_filepath):
        tmp_taxonomy_map = []
        with open(taxonomy_map_filepath, 'r') as map_file:
            csv_reader = csv.reader(map_file, delimiter=cls._tax_map_csv_delimiter, quotechar=cls._tax_map_csv_quote)
            for row in csv_reader:
                tmp_taxonomy_map.append(row)
        taxonomy_map = pd.DataFrame(data=[[e[0], e[2]] for e in tmp_taxonomy_map], index=[e[1] for e in tmp_taxonomy_map], columns=['lineage', 'level'])
        return taxonomy_map

    @classmethod
    def _construct_taxonomy_sheet(cls, taxonomy_map):
        SILVA_RANKS = Consts.MAIN_RANKS[:-1]
        master_taxonomy_sheet = pd.DataFrame(columns=SILVA_RANKS, index=taxonomy_map.index, data=None)
        rank = SILVA_RANKS[0]
        master_taxonomy_sheet.loc[:, rank] = taxonomy_map.loc[ taxonomy_map.loc[:, 'level'] == Consts.ITS['r2rank'][rank], :].apply(lambda row: row['lineage'][:-1].split(';')[0], axis=1)
        for rank in SILVA_RANKS[1:]:
            master_taxonomy_sheet.loc[:, rank] = taxonomy_map.loc[ taxonomy_map.loc[:, 'level'] == Consts.ITS['r2rank'][rank], :].apply(lambda row: row['lineage'][:-1].split(';'), axis=1)

        def reassign(taxons, r):
            new_taxa = {r: taxons.pop()}
            for r_i in SILVA_RANKS[:SILVA_RANKS.index(r)]:
                for t_i in range(len(taxons)):
                    if taxons[t_i] in master_taxonomy_sheet.loc[master_taxonomy_sheet.loc[:, r_i].notna(), r_i].values:
                        new_taxa[r_i] = taxons[t_i]
                        taxons.pop(t_i)
                        break
            return pd.Series(new_taxa)

        for rank in SILVA_RANKS[1:]:
            master_taxonomy_sheet.update(master_taxonomy_sheet.loc[master_taxonomy_sheet.loc[:, rank].notna(), rank].apply(reassign, r=rank))

        master_taxonomy_sheet.insert(loc=len(master_taxonomy_sheet.columns), column='s', value='')
        master_taxonomy_sheet = master_taxonomy_sheet.applymap(lambda x: None if pd.isna(x) else x)
        return master_taxonomy_sheet

    @classmethod
    def _parse_sequence_generator(cls, fasta_filepath):
        seq_iterator = SeqIO.parse(open(fasta_filepath), 'fasta')
        max_seq_length = 0
        max_id_length = 0
        max_desc_length = 0
        max_rows = 0
        for seq_record in seq_iterator:
            seq_length = len(seq_record.seq)
            id_length = len(str(seq_record.id))
            desc_length = len(seq_record.description)
            max_seq_length = seq_length if seq_length > max_seq_length else max_seq_length
            max_id_length = id_length if id_length > max_id_length else max_id_length
            max_desc_length = desc_length if desc_length > max_desc_length else max_desc_length
            max_rows = max_rows + 1
        seq_iterator = SeqIO.parse(open(fasta_filepath), 'fasta')
        chunk_counter = cls._sequence_chunk_size
        next_chunk = True
        first_chunk = True
        while next_chunk:
            sequences_list = []
            for seq_record in seq_iterator:
                if chunk_counter > 1:
                    sequences_list.append([str(seq_record.id), str(seq_record.description), str(seq_record.seq)])
                    chunk_counter = chunk_counter - 1
                else:
                    chunk_counter = cls._sequence_chunk_size
                    sequences_list.append([str(seq_record.id), str(seq_record.description), str(seq_record.seq)])
                    break
            if len(sequences_list) > 0:
                chunk_df = pd.DataFrame.from_records(sequences_list, columns=['index', 'description', 'sequence'], index=['index'])
                if first_chunk:
                    first_chunk = False
                    pre_state_dict = {'index': max_id_length,'description': max_desc_length, 'sequence': max_seq_length, 'max_rows': max_rows}
                    yield pre_state_dict, chunk_df
                else:
                    yield chunk_df
            else:
                next_chunk = False
        return

    @classmethod
    def _parse_sequence_accessions(cls, accession_map_filepath):
        tmp_accession_map = []
        with open(accession_map_filepath, 'r') as map_file:
            csv_reader = csv.reader(map_file, delimiter=cls._tax_map_csv_delimiter, quotechar=cls._tax_map_csv_quote)
            for row in csv_reader:
                tmp_accession_map.append(row)
        accession_map = pd.DataFrame.from_records(tmp_accession_map,index=['index'],columns=['index','taxid'])
        return accession_map

    @classmethod
    def _make_tree_from_newick(cls, newick_path):
        tmp_map_tree = ete3.Tree(newick_path, format=8)
        return tmp_map_tree

    @classmethod
    def _rebuild_and_transform_from_tree_object(cls, tree_object):
        tmp_map_tree = tree_object
        nodes_with_no_names = [node for node in tmp_map_tree.traverse() if node.name == '' or node.name is None]
        missing_nodes_names = []

        for node in nodes_with_no_names:
            new_name = round(random() * 100000, None)
            while new_name in missing_nodes_names:
                new_name = round(random() * 100000, None)
            missing_nodes_names.append(new_name)
            node.name = '+{}'.format(str(new_name))

        all_names = [node.name for node in tmp_map_tree.traverse()]

        duplicated_names = [name for name, count in collections.Counter(all_names).items() if count > 1]
        duplicated_nodes = [tmp_map_tree.search_nodes(name=node_name) for node_name in duplicated_names]

        for nodes in duplicated_nodes:
            counter = 1
            for node in nodes:
                new_name = '{}+{}'.format(str(counter), node.name)
                node.name = new_name
                counter = counter + 1
        return tmp_map_tree

    @classmethod
    def _transform_tree_to_newick(cls, tree_object):
        with NamedTemporaryFile(mode='w+') as tmp_newick_io:
            tree_object.write(format=8, outfile=tmp_newick_io.name, format_root_node=True)
            tmp_newick_io.file.seek(0)
            ret = tmp_newick_io.file.read()
        return ret

    @classmethod
    def _transformed_tree_to_map(cls, tree_object):
        uid_map_list = []
        for node in tree_object.traverse('postorder'):
            if not node.is_root():
                uid_map_list.append([node.name, node.up.name])
            else:
                uid_map_list.append([node.name, ''])

        tree_map = pd.DataFrame.from_records(uid_map_list, columns=['uid', 'pid'], index=['uid'])
        tree_map.index = tree_map.index.map(str)
        ret = tree_map.applymap(str)
        return ret

    @classmethod
    def _summarize_taxonomy_sheet(cls, master_taxonomy_sheet):
        database_summary = {}
        master_taxonomy_sheet.loc[:, Consts.MAIN_RANKS] = master_taxonomy_sheet.loc[:, Consts.MAIN_RANKS].applymap(lambda x: None if (x == '') else x)
        avail_ranks = [rank for rank in Consts.MAIN_RANKS if master_taxonomy_sheet.loc[:, rank].notna().any()]
        master_taxonomy_sheet.loc[:, 'lineage'] = SharedMethods.generate_lineages_from_taxa(master_taxonomy_sheet, True, avail_ranks, False)
        database_summary.update({'available-ranks': ','.join(avail_ranks)})

        total_taxa = master_taxonomy_sheet.shape[0]
        database_summary.update({'total-taxa': str(total_taxa)})

        total_duplicated_taxa = master_taxonomy_sheet[master_taxonomy_sheet.duplicated(subset=['lineage'], keep=False)].drop_duplicates(subset=['lineage']).reset_index(drop=True).shape[0]
        database_summary.update({'total-duplicated-taxa': str(total_duplicated_taxa)})

        total_unduplicated_taxa = master_taxonomy_sheet.drop_duplicates(subset=['lineage']).reset_index(drop=True).shape[0]
        database_summary.update({'total-unduplicated-taxa': str(total_unduplicated_taxa)})

        total_unique_taxa = master_taxonomy_sheet[~master_taxonomy_sheet.duplicated(subset=['lineage'], keep=False)].shape[0]
        database_summary.update({'total-unique-taxa': str(total_unique_taxa)})

        def summarize_for_rank(rank):
            if rank in avail_ranks:
                total = master_taxonomy_sheet[master_taxonomy_sheet[rank].notna()][rank]
                duplicated = total.duplicated(keep=False)
                unique = total[~duplicated].dropna()
                count_shared = 0
                if rank in avail_ranks:
                    prior_ranks = SharedMethods.get_rank_upto(avail_ranks, rank)
                    if prior_ranks:
                        filter_dup = master_taxonomy_sheet[master_taxonomy_sheet.duplicated(subset=[rank], keep=False)].dropna(subset=[rank])[avail_ranks].drop_duplicates(subset=prior_ranks)
                        count_shared = filter_dup[filter_dup.duplicated(subset=rank, keep=False)].reset_index(drop=True).shape[0]
                count_total = total.shape[0]
                count_duplicated = sum(duplicated)
                count_unique = unique.shape[0]

                return {'total': str(count_total), 'duplicated': str(count_duplicated), 'unique': str(count_unique), 'shared-with-other-taxa': str(count_shared)}
            else:
                return {'total': str(0), 'duplicated': str(0), 'unique': str(0), 'shared-with-other-taxa': str(0)}

        for rank in Consts.MAIN_RANKS:
            rank_name_full = Consts.ITS['r2rank'][rank]
            summary = summarize_for_rank(rank)
            database_summary.update({'{}-total'.format(rank_name_full): summary['total']})
            database_summary.update({'{}-duplicated'.format(rank_name_full): summary['duplicated']})
            database_summary.update({'{}-unique'.format(rank_name_full): summary['unique']})
            database_summary.update({'{}-shared'.format(rank_name_full): summary['shared-with-other-taxa']})

        summary_series = pd.Series(database_summary).map(str)
        return summary_series


    @property
    def _storage_elements(self):
        return self._required_storage_elements

    @property
    def name(self):
        return self._database_class_name

    @property
    def tree_object(self):
        if self.is_tree_object:
            return self._request_loaded_tree_object()
        else:
            return None

    @property
    def tree_map(self):
        if self.is_tree_map:
            return self._retrieve_tree_map()
        else:
            return None

    @property
    def sequence_accession(self):
        if self.is_seq_acc:
            tmp_acc_series = self._retrieve_sequence_accession()['taxid']
            return tmp_acc_series.groupby(tmp_acc_series).apply(lambda group: group.index.values)
        else:
            return None

    @property
    def taxonomy_sheet(self):
        if self.is_tax_sheet:
            if self._temp_cache_taxonomy_sheet is None:
                return self._retrieve_taxonomy_sheet()
            else:
                return self._temp_cache_taxonomy_sheet
        else:
            return None

    @property
    def taxonomy_map(self):
        return self._retrieve_taxonomy_map()
