from random import random
from os import path
from tempfile import NamedTemporaryFile
import re
import ete3
import pandas as pd
from pmaf.database._base import DatabaseBase
from pmaf.database._meta import DatabasePrimaryWrapperMeta
from pmaf.shared import Consts,SharedMethods

class DatabaseOTL(DatabaseBase,DatabasePrimaryWrapperMeta):
    _tax_map_csv_delimiter = '\t[|]\t'
    _tax_map_csv_quote = '"'
    _tax_map_tsv_headers = ['uid', 'parent_uid', 'name', 'rank', 'sourceinfo', 'uniqname']
    _database_class_name = 'OpenTreeOfLife'
    _inter_index_map_elements = ['taxonomy-map', 'taxonomy-sheet','sequence-accession']
    _regex_mrca_tags = re.compile('mrcaott[0-9]+ott[0-9]+')
    _regex_ott_tags = re.compile('ott([0-9]+)')
    _allowed_taxon_ranks = ['domain', 'kingdom', 'phylum', 'class', 'order', 'family', 'genus', 'species', 'no rank - terminal']

    def __init__(self, storage_path=None,force_interxmap=False):
     super().__init__()
     self._temp_cache_taxonomy_sheet = None
     self._required_storage_elements = ['tree-parsed', 'tree-object', 'tree-map', 'taxonomy-map', 'taxonomy-sheet', 'sequence-accession', 'taxonomy-summary']
     self._inter_index_map = None
     if storage_path is not None:
         if not self.load_database_storage(storage_path,force_interxmap):
             raise ValueError('Storage file is invalid.')

    def _init_inter_index_map(self, cached_interxmap=None):
        ret = False
        if self.check_init():
            if cached_interxmap is None:
                tmp_inter_index_map = self._construct_inter_index_map(self.storage_manager)
                if tmp_inter_index_map is not None:
                    self._inter_index_map = tmp_inter_index_map
                    ret = True
            else:
                target_elements = [elem_key for elem_key in self._inter_index_map_elements if self._verify_storage_element(elem_key)]
                if len(target_elements) > 0:
                    if cached_interxmap.columns.isin(target_elements).sum() == len(target_elements):
                        self._inter_index_map = cached_interxmap
                        ret = True
        return ret

    def _get_coordinates_for_element_by_ids(self, element, ids):
        ret = None
        if self._init_state[element]:
            id_list = SharedMethods.ensure_list(ids)
            if len(id_list) > 0:
                if element in self._inter_index_map.columns:
                    tmp_target_index_map = self._inter_index_map.loc[self._inter_index_map.index[self._inter_index_map.index.isin(id_list)], element]
                    ret = pd.Index(tmp_target_index_map.values)
        return ret

    def load_database_storage(self,storage_hdf5_path,force_interxmap=False):
        if self._load_database_storage(storage_hdf5_path, self._database_class_name,force_interxmap):
            return True
        else:
            raise RuntimeError('Cannot load provided storage file. ')

    def build_database_storage(self, storage_hdf5_path, taxonomy_map_csv_path, tree_newick_path,**kwargs):
        if self._build_database_storage(storage_hdf5_path, taxonomy_map_csv_path, tree_newick_path,**kwargs):
            return storage_hdf5_path
        else:
            raise RuntimeError('Cannot create database storage. Check if file already exists.')

    def load_cache_taxonomy_sheet(self):
        ret = False
        tmp_taxonomy_sheet = self._retrieve_taxonomy_sheet()
        if tmp_taxonomy_sheet is not None:
            self._temp_cache_taxonomy_sheet = tmp_taxonomy_sheet
            ret = True
        return ret

    def release_temporary_cache(self):
        self._temp_cache_taxonomy_sheet = None
        return

    def generate_lineages(self, missing_rank=False, desired_ranks=False, drop_ranks=False):
        if self._temp_cache_taxonomy_sheet is not None:
            return SharedMethods.generate_lineages_from_taxa(self._temp_cache_taxonomy_sheet, missing_rank, desired_ranks, drop_ranks)
        else:
            return super().generate_lineages(missing_rank, desired_ranks, drop_ranks)

    def get_taxonomy_by_ids(self, ids):
        ret = False
        if self.is_tax_sheet:
            taxa_ids = SharedMethods.ensure_list(ids)
            if len(taxa_ids) > 0:
                if self.uids.isin(taxa_ids).sum() == len(taxa_ids):
                    if self._temp_cache_taxonomy_sheet is not None:
                        target_taxonomy_df = self._temp_cache_taxonomy_sheet.loc[taxa_ids, :]
                    else:
                        target_taxonomy_df = self._get_taxonomy_sheet_by_ids(taxa_ids)
                    ret = target_taxonomy_df.loc[:, self.get_avail_ranks()]
        return ret

    def get_lingeages_by_ids(self, ids):
        ret = False
        if self.is_tax_sheet:
            taxa_ids = SharedMethods.ensure_list(ids)
            if len(taxa_ids) > 0:
                if self.uids.isin(taxa_ids).sum() == len(taxa_ids):
                    if self._temp_cache_taxonomy_sheet is not None:
                        target_taxonomy_df = self._temp_cache_taxonomy_sheet.loc[taxa_ids, :]
                    else:
                        target_taxonomy_df = self._get_taxonomy_sheet_by_ids(taxa_ids)
                    ret = self.generate_lineages_by_sheet_df(target_taxonomy_df)
        return ret

    def get_sequence_acc_by_ids(self, ids):
        ret = False
        if self.is_seq_acc:
            taxa_ids = SharedMethods.ensure_list(ids)
            if len(taxa_ids) > 0:
                if self.uids.isin(taxa_ids).sum() == len(taxa_ids):
                    tmp_target_sequence_acc_df = self._get_sequence_accession_by_ids(taxa_ids)
                    target_sequence_acc_df = tmp_target_sequence_acc_df.applymap(lambda acc_elem: acc_elem.split('|') if acc_elem is not None else acc_elem)
                    ret = target_sequence_acc_df
        return ret

    def get_sequence_by_ids(self,*args,**kwargs):
        return False

    def get_sequence_aligned_by_ids(self,*args,**kwargs):
        return False

    @classmethod
    def _construct_inter_index_map(cls, storage_manager):
        ret = None
        if storage_manager.check_state():
            target_elements = [elem_key for elem_key in cls._inter_index_map_elements if storage_manager.validate_element_key(elem_key)]
            if len(target_elements) > 0:
                first_element = target_elements[0]
                internal_index_map = storage_manager.get_index_by_element(first_element)
                internal_index_map = internal_index_map.reset_index(name='target').set_index('target').rename({'index': first_element}, axis=1)
                if len(target_elements) > 1:
                    for element in target_elements[1:]:
                        next_elemenet_index_map = storage_manager.get_index_by_element(element)
                        next_elemenet_index_map = next_elemenet_index_map.reset_index(name='target').set_index('target').rename({'index': element}, axis=1)
                        internal_index_map = internal_index_map.join(next_elemenet_index_map, how='left')
                internal_index_map.sort_index(inplace=True)
                internal_index_map.index.rename('index', inplace=True)
                ret = internal_index_map
        return ret

    @classmethod
    def _build_database_storage(cls, storage_hdf5_path, taxonomy_map_csv_path, tree_newick_path,**kwargs):
        parser_elements = {}
        if isinstance(taxonomy_map_csv_path, str) and isinstance(tree_newick_path,str):
            if path.isfile(taxonomy_map_csv_path) and path.isfile(tree_newick_path):
                parser_elements.update({'tree-parsed': {'handle': cls._parse_newick_tree, 'params': (tree_newick_path,), 'pass': True, 'receive': None}})
                parser_elements.update({'tree-object': {'handle': cls._make_tree_from_newick, 'params': (), 'pass': True, 'receive': 'tree-parsed'}})
                parser_elements.update({'tree-map': {'handle': cls._rebuild_and_transform_from_tree_to_map, 'params': (), 'pass': 2, 'receive': 'tree-object'}})
                parser_elements.update({'taxonomy-map': {'handle': cls._parse_taxonomy_map, 'params': (taxonomy_map_csv_path,), 'pass': True, 'receive': 'tree-map'}})
                parser_elements.update({'sequence-accession': {'handle': cls._parse_sequence_accessions, 'params': (), 'pass': 2, 'receive': 'taxonomy-map'}})
                parser_elements.update({'taxonomy-sheet': {'handle': cls._construct_taxonomy_sheet, 'params': (taxonomy_map_csv_path,), 'pass': True, 'receive': 'sequence-accession'}})
                parser_elements.update({'taxonomy-summary': {'handle': cls._summarize_taxonomy_sheet, 'params': (), 'pass': False, 'receive': 'taxonomy-sheet'}})
        return cls._construct_database_storage(storage_hdf5_path, cls._database_class_name, parser_elements,**kwargs)


    @classmethod
    def _parse_newick_tree(cls, ott_newick_path):
        with open(ott_newick_path, 'r') as tree_file:
            newick_string = tree_file.read()
        newick_string_no_mrca_tag = re.sub(cls._regex_mrca_tags, "", newick_string)
        newick_string_parsed = re.sub(cls._regex_ott_tags, "\\1", newick_string_no_mrca_tag)
        return newick_string_parsed

    @classmethod
    def _make_tree_from_newick(cls, newick_string):
        tmp_map_tree = ete3.Tree(newick_string, format=8)
        return tmp_map_tree

    @classmethod
    def _rebuild_and_transform_from_tree_to_map(cls, tree_object):
        tmp_map_tree = tree_object.copy('newick')
        nodes_cached = tmp_map_tree.get_cached_content()
        nodes_with_no_names = [node for node in nodes_cached.keys() if node.name == '' or node.name is None]
        missing_nodes_names = []

        for node in nodes_with_no_names:
            new_name = round(random() * 100000, None)
            while new_name in missing_nodes_names:
                new_name = round(random() * 100000, None)
            missing_nodes_names.append(new_name)
            node.name = '+{}'.format(str(new_name))

        all_nodes = list(nodes_cached.keys())
        all_names = [node.name for node in all_nodes]
        node_df = pd.Series(data=all_names, index=range(len(all_names)))
        node_duplicated = node_df[node_df.duplicated(keep=False)]
        node_gby = node_duplicated.groupby(node_duplicated)
        duplicated_nodes = node_gby.apply(lambda group: [all_nodes[index] for index in group.index.values]).values.tolist()

        for nodes in duplicated_nodes:
            counter = 1
            for node in nodes:
                new_name = '{}+{}'.format(str(counter), node.name)
                node.name = new_name
                counter = counter + 1

        uid_map_list = []
        for node in tmp_map_tree.traverse('postorder'):
            if not node.is_root():
                uid_map_list.append([node.name, node.up.name])
            else:
                uid_map_list.append([node.name, ''])

        tree_map = pd.DataFrame.from_records(uid_map_list, columns=['uid', 'pid'], index=['uid'])
        tree_map.index = tree_map.index.map(str)
        ret = tree_map.applymap(str)
        return ret

    @classmethod
    def _parse_taxonomy_map(cls, taxonomy_map_filepath, tree_object):
        all_ott_ids_in_tree = list(set([str(node.name) for node in tree_object.traverse() if node.name is not None and node.name != '']))
        tmp_taxonomy_map = pd.read_csv(taxonomy_map_filepath, index_col='uid', sep=cls._tax_map_csv_delimiter, usecols=cls._tax_map_tsv_headers,engine='python', header=0, dtype=str)
        tmp_taxonomy_map.index = tmp_taxonomy_map.index.map(str)
        tmp_taxonomy_map = tmp_taxonomy_map.applymap(lambda x:'' if pd.isna(x) else x)
        filtered_index = tmp_taxonomy_map.index[tmp_taxonomy_map.index.isin(all_ott_ids_in_tree)]
        taxonomy_map = tmp_taxonomy_map.loc[filtered_index]
        taxonomy_map = taxonomy_map[taxonomy_map['rank'].isin(cls._allowed_taxon_ranks)]
        return taxonomy_map

    @classmethod
    def _parse_sequence_accessions(cls, taxonomy_map_df):
        from collections import defaultdict
        acc_map_series = taxonomy_map_df.loc[:, 'sourceinfo']
        def acc_rearranger(taxon_acc):
            acc_split = taxon_acc.split(',')
            acc_type_split = [acc_data.split(':') for acc_data in acc_split]
            acc_parsed = defaultdict(list)
            for acc_elem in acc_type_split:
                if 'additions' not in acc_elem[0]: # This fixes invalid sourceinfo elements within OTT taxonomy.tsv file.
                    acc_parsed[acc_elem[0]].append(acc_elem[1])
            return {key: '|'.join(values) for key, values in acc_parsed.items()}
        acc_map_arranged_dict = acc_map_series.map(acc_rearranger).to_dict()
        del acc_map_series
        total_taxid = len(acc_map_arranged_dict)
        all_acc_types = [list(taxon_acc.keys()) for taxon_acc in acc_map_arranged_dict.values()]
        unique_acc_types = list(set(list([acc_type for acc_types in all_acc_types for acc_type in acc_types])))
        del all_acc_types
        def valid_acc_generator(acc_map_dict):
            for taxid,acc_dict in acc_map_dict.items():
                yield [taxid]+[acc_dict.get(acc_type,'') for acc_type in unique_acc_types]
        accession_map_df = pd.DataFrame.from_records(valid_acc_generator(acc_map_arranged_dict),index=['index'], columns=['index']+unique_acc_types, nrows=total_taxid)
        accession_map_df.index = accession_map_df.index.map(str)
        return accession_map_df

    @classmethod
    def _construct_taxonomy_sheet(cls, taxonomy_map_filepath, taxonomy_map):
        all_target_ids = taxonomy_map.index.values.tolist()
        del taxonomy_map
        complete_taxonomy_map = pd.read_csv(taxonomy_map_filepath, index_col='uid', sep=cls._tax_map_csv_delimiter, usecols=cls._tax_map_tsv_headers,engine='python', header=0, dtype=str)
        with NamedTemporaryFile() as tmp_taxonomy:
            complete_taxonomy_map.to_csv(tmp_taxonomy.name, sep='|', columns=['parent_uid', 'name', 'rank'],index_label='uid')
            del complete_taxonomy_map
            tmp_ott_sheet = SharedMethods.CyMethods.rapid_ott_taxonomy_reader(Consts.MAIN_RANKS, tmp_taxonomy.name, '|')
        tmp_taxonomy_sheet = pd.DataFrame.from_records(tmp_ott_sheet, columns=['uid', 'pid'] + Consts.MAIN_RANKS, index=['uid'], exclude=['pid'])
        tmp_taxonomy_sheet.index = tmp_taxonomy_sheet.index.map(str)
        filtered_index = tmp_taxonomy_sheet.index[tmp_taxonomy_sheet.index.isin(all_target_ids)]
        taxonomy_sheet = tmp_taxonomy_sheet.loc[filtered_index,:].applymap(lambda x: '' if pd.isna(x) else x)
        return taxonomy_sheet

    @classmethod
    def _summarize_taxonomy_sheet(cls, master_taxonomy_sheet):
        database_summary = {}
        master_taxonomy_sheet.loc[:, Consts.MAIN_RANKS] = master_taxonomy_sheet.loc[:, Consts.MAIN_RANKS].applymap(lambda x: None if (x == '') else x)
        avail_ranks = [rank for rank in Consts.MAIN_RANKS if master_taxonomy_sheet.loc[:, rank].notna().any()]
        master_taxonomy_sheet.loc[:, 'lineage'] = SharedMethods.generate_lineages_from_taxa(master_taxonomy_sheet, True, avail_ranks, False)
        database_summary.update({'available-ranks': ','.join(avail_ranks)})

        total_taxa = master_taxonomy_sheet.shape[0]
        database_summary.update({'total-taxa': str(total_taxa)})

        total_duplicated_taxa = master_taxonomy_sheet[master_taxonomy_sheet.duplicated(subset=['lineage'], keep=False)].drop_duplicates(subset=['lineage']).reset_index(drop=True).shape[0]
        database_summary.update({'total-duplicated-taxa': str(total_duplicated_taxa)})

        total_unduplicated_taxa = master_taxonomy_sheet.drop_duplicates(subset=['lineage']).reset_index(drop=True).shape[0]
        database_summary.update({'total-unduplicated-taxa': str(total_unduplicated_taxa)})

        total_unique_taxa = master_taxonomy_sheet[~master_taxonomy_sheet.duplicated(subset=['lineage'], keep=False)].shape[0]
        database_summary.update({'total-unique-taxa': str(total_unique_taxa)})

        def summarize_for_rank(rank):
            if rank in avail_ranks:
                total = master_taxonomy_sheet[master_taxonomy_sheet[rank].notna()][rank]
                duplicated = total.duplicated(keep=False)
                unique = total[~duplicated].dropna()
                count_shared = 0
                if rank in avail_ranks:
                    prior_ranks = SharedMethods.get_rank_upto(avail_ranks, rank)
                    if prior_ranks:
                        filter_dup = master_taxonomy_sheet[master_taxonomy_sheet.duplicated(subset=[rank], keep=False)].dropna(subset=[rank])[avail_ranks].drop_duplicates(subset=prior_ranks)
                        count_shared = filter_dup[filter_dup.duplicated(subset=rank, keep=False)].reset_index(drop=True).shape[0]
                count_total = total.shape[0]
                count_duplicated = sum(duplicated)
                count_unique = unique.shape[0]

                return {'total': str(count_total), 'duplicated': str(count_duplicated), 'unique': str(count_unique), 'shared-with-other-taxa': str(count_shared)}
            else:
                return {'total': str(0), 'duplicated': str(0), 'unique': str(0), 'shared-with-other-taxa': str(0)}

        for rank in Consts.MAIN_RANKS:
            rank_name_full = Consts.ITS['r2rank'][rank]
            summary = summarize_for_rank(rank)
            database_summary.update({'{}-total'.format(rank_name_full): summary['total']})
            database_summary.update({'{}-duplicated'.format(rank_name_full): summary['duplicated']})
            database_summary.update({'{}-unique'.format(rank_name_full): summary['unique']})
            database_summary.update({'{}-shared'.format(rank_name_full): summary['shared-with-other-taxa']})

        summary_series = pd.Series(database_summary).map(str)
        return summary_series

    @property
    def _storage_elements(self):
        return self._required_storage_elements

    @property
    def name(self):
        return self._database_class_name

    @property
    def tree_object(self):
        if self.is_tree_object:
            return self._request_loaded_tree_object()
        else:
            return None

    @property
    def tree_map(self):
        if self.is_tree_map:
            return self._retrieve_tree_map()
        else:
            return None

    @property
    def sequence_accession(self):
        if self.is_seq_acc:
            return self._retrieve_sequence_accession()
        else:
            return None

    @property
    def taxonomy_sheet(self):
        if self.is_tax_sheet:
            if self._temp_cache_taxonomy_sheet is None:
                return self._retrieve_taxonomy_sheet()
            else:
                return self._temp_cache_taxonomy_sheet
        else:
            return None

    @property
    def taxonomy_map(self):
        return self._retrieve_taxonomy_map()
