from abc import ABC,abstractmethod

class DatabaseBaseMeta(ABC):

    @abstractmethod
    def _load_database_storage(self,hdf5_path,database_name,force_new_interxmap):
        pass

    @abstractmethod
    def _init_internals(self,cached_interxmap):
        pass

    @abstractmethod
    def _verify_element_state(self,element):
        pass

    @abstractmethod
    def close(self):
        pass

    @abstractmethod
    def generate_lineages(self,missing_rank, desired_ranks,drop_ranks):
        pass

    @abstractmethod
    def generate_lineages_by_sheet_df(self,sheet_df,missing_rank, drop_ranks):
        pass

    @abstractmethod
    def get_avail_ranks(self):
        pass

    @abstractmethod
    def _get_taxonomy_sheet_by_ids(self, ids):
        pass

    @abstractmethod
    def _get_taxonomy_map_by_ids(self, ids):
        pass

    @abstractmethod
    def _get_sequence_master_by_ids(self, ids):
        pass

    @abstractmethod
    def _get_sequence_aligned_by_ids(self, ids):
        pass

    @abstractmethod
    def _get_sequence_accession_by_ids(self, ids):
        pass

    @abstractmethod
    def _retrieve_taxonomy_sheet(self):
        pass

    @abstractmethod
    def _retrieve_taxonomy_map(self):
        pass

    @abstractmethod
    def _retrieve_taxonomy_summary(self):
        pass

    @abstractmethod
    def _retrieve_sequence_master(self):
        pass

    @abstractmethod
    def _retrieve_sequence_aligned(self):
        pass

    @abstractmethod
    def _retrieve_sequence_accession(self):
        pass

    @abstractmethod
    def _retrieve_tree_map(self):
        pass

    @abstractmethod
    def _retrieve_tree_parsed(self):
        pass

    @abstractmethod
    def _retrieve_tree_object(self):
        pass

    @abstractmethod
    def _get_coordinates_for_element_by_ids(self,element,ids):
        pass

    @abstractmethod
    def _request_loaded_tree_object(self):
        pass

    @abstractmethod
    def prune_tree_by_ids(self,tip_ids):
        pass

    @abstractmethod
    def infer_topology_by_ids(self,tip_ids):
        pass

    @abstractmethod
    def check_init(self):
        pass

    @abstractmethod
    def _verify_storage_element(self,element):
        pass

    @abstractmethod
    def _init_inter_index_map(self,cached_interxmap):
        pass

    @classmethod
    @abstractmethod
    def _construct_inter_index_map(cls, storage_manager):
        pass

    @classmethod
    @abstractmethod
    def _build_database_storage(cls, **kwargs):
        pass

    @classmethod
    @abstractmethod
    def _construct_database_storage(cls,hdf5_path,database_name,parser_elements,**kwargs):
        pass

    @staticmethod
    @abstractmethod
    def _map_missing_as_nan(map_frame):
        pass

    @property
    @abstractmethod
    def _storage_elements(self):
        pass

    @property
    @abstractmethod
    def taxonomy_summary(self):
        pass

    @property
    @abstractmethod
    def uids(self):
        pass

    @property
    @abstractmethod
    def name(self):
        pass

    @property
    @abstractmethod
    def state(self):
        pass

    @property
    @abstractmethod
    def storage_manager(self):
        pass

    @property
    @abstractmethod
    def is_seq(self):
        pass

    @property
    @abstractmethod
    def is_seq_aligned(self):
        pass

    @property
    @abstractmethod
    def is_seq_acc(self):
        pass

    @property
    @abstractmethod
    def is_tax_map(self):
        pass

    @property
    @abstractmethod
    def is_tax_sheet(self):
        pass

    @property
    @abstractmethod
    def is_tree_map(self):
        pass

    @property
    @abstractmethod
    def is_tree_parsed(self):
        pass

    @property
    @abstractmethod
    def is_tree_object(self):
        pass

class DatabasePrimaryWrapperMeta(DatabaseBaseMeta):

    @abstractmethod
    def load_database_storage(self, hdf5_path):
        pass

    @abstractmethod
    def build_database_storage(self,**kwargs):
        pass

    @abstractmethod
    def get_taxonomy_by_ids(self, ids):
        pass

    @abstractmethod
    def get_lingeages_by_ids(self, ids):
        pass

    @abstractmethod
    def get_sequence_acc_by_ids(self, ids):
        pass

    @abstractmethod
    def get_sequence_by_ids(self, ids):
        pass

    @abstractmethod
    def get_sequence_aligned_by_ids(self, ids):
        pass

    @abstractmethod
    def load_cache_taxonomy_sheet(self):
        pass

    @abstractmethod
    def release_temporary_cache(self):
        pass

    @abstractmethod
    def _get_coordinates_for_element_by_ids(self,element,ids):
        pass

    @abstractmethod
    def _init_inter_index_map(self,cached_interxmap):
        pass

    @classmethod
    @abstractmethod
    def _construct_inter_index_map(cls,storage_manager):
        pass

    @classmethod
    @abstractmethod
    def _build_database_storage(cls,**kwargs):
        pass

