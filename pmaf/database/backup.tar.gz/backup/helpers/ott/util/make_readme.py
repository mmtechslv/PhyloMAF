
import sys, os, json

issue = sys.argv[1]

print '<p>Stub - to be filled out later</p>'

print 'need version number, commit, sources, etc'

