## Version 2.2 release notes

## Download

[Download](http://files.opentreeoflife.org/ott/ott2.2/ott2.2.tgz) (gzipped tar file, 123 Mbyte) 

## Release notes
