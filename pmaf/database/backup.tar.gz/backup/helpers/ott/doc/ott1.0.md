## OTT (OTToL) version 1.0

OTT version 1.0 (or OTToL 1.0, as it was called at the time) was generated using 
[taxomachine](https://github.com/OpenTreeOfLife/taxomachine) on or before 2013-03-16.

It combines the NCBI Taxonomy with the GBIF taxonomy.

The taxonomy file has a column that maps identifiers from the 'preottol' taxonomy,
which was used by phylografter up to this point in the project.

## Download

[Gzipped tar file, 34 Mbyte](https://bitbucket.org/blackrim/avatol-taxonomies/downloads/ottol_dumpv1_w_preottol_ids_uniqunames.tar.gz)

