# How the OTT build system works

Diagram [here](ott-management-design.svg) (SVG).

OTT is built from the following

1. 'smasher,' a taxonomy manipulation library
2. scripts including 'assemble-ott' in the reference-taxonomy repository
3. curated data in the reference-taxonomy repository (e.g. the separation taxonomy)
4. 
