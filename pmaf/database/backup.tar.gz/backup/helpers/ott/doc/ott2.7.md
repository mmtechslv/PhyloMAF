
OTT 2.7 was created on or shortly before 8 May 2014.

[reference-taxonomy commit 798e80eb82c87ec006c72386f1f7b38fe0fff7c7](https://github.com/OpenTreeOfLife/reference-taxonomy/commit/798e80eb82c87ec006c72386f1f7b38fe0fff7c7)

## Download

[Download](http://files.opentreeoflife.org/ott/ott2.7/ott2.7.tgz) (gzipped tar file, 102 Mbyte) 

## Release notes

* No major changes relative to OTT 2.6
* Many low-level tweaks to taxonomy
* New rank 'no rank - terminal', a synonym for 'no rank' in cases where there are no children
