
1. [Abstract and introduction](introduction.md)
1. Method
    1. [Source taxonomies](sources.md)
    1. [Alignment, merging](method.md)
1. [Results and discussion](results-discussion.md)
1. [References](to_cite.bib)
