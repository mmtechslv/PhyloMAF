
Doing `make` creates a file `draft.html` which you can open in a
browser.  On OS X, doing `make open` creates `draft.html` and then
opens it in your default browser.
