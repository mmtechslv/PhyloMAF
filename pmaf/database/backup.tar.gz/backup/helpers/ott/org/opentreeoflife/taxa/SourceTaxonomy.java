package org.opentreeoflife.taxa;

import java.io.PrintStream;
import java.io.IOException;

public class SourceTaxonomy extends Taxonomy {

	public SourceTaxonomy() {
        super();
	}

	public SourceTaxonomy(String idspace) {
        super(idspace);
	}
}


