
package org.opentreeoflife.taxa;

public interface SimpleMap<D, R> {
    R get(D key);
}

