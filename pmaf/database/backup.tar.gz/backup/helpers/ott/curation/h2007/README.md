This taxonomy of the fungal classification was copied from

Gazis, Romina (2015): Fungal Classification 2015. figshare. 
https://dx.doi.org/10.6084/m9.figshare.1465038.v6



